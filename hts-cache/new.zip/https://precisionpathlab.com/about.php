<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=0" /> 

  <title> About Us |Precision Path lab Jaipur </title>
  <meta content="Discover Precision Path Lab, a trusted provider of accurate diagnostic services. With advanced technology and a dedicated team, we deliver precise results for better patient outcomes." name="description">
  <meta content="" name="keywords">
	<meta property="og:image" content="https://precisionpathlab.com/assets/img/pathlab.png">
	
	<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-D8QG004XC3"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-D8QG004XC3');
</script>

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

 <link rel="canonical" href="https://precisionpathlab.com/about.php">
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
	<style>
    /* CSS for the WhatsApp widget */
    .whatsapp-widget {
      position: fixed;
      bottom: 75px;
		width:150px;
		background-color:#00a884;
		border-radius:5%;
      right: -170px; /* Initially hidden */
      z-index: 9999;
      transition: right 0.3s ease-in-out;
    }
    .whatsapp-widget:hover {
      right: 20px; /* Display on hover */
    }
    .whatsapp-widget img {
      width: 50px;
      height: 50px;
    }
  </style>

</head>

<body>

  <!-- ======= Top Bar ======= -->
  <div id="topbar" class="d-flex align-items-center fixed-top">
    <div class="container d-flex justify-content-between">
      <div class="contact-info d-flex align-items-center">
        <i class="bi bi-envelope"></i> <a href="mailto:contact@example.com">info@precisionpathlab.com</a>
        <i class="bi bi-phone"></i> +91-7230002896 
      </div>
      <div class="d-none d-lg-flex social-links align-items-center">
      
        <a href="https://www.facebook.com/precisonpathlab" class="facebook"><i class="bx bxl-facebook"></i></a>
        <a href="https://www.instagram.com/precisionpathlab/" class="instagram"><i class="bi bi-instagram"></i></a>
      </div>
    </div>
  </div>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center">

	<a href="https://precisionpathlab.com/" class="logo me-auto"><img src="assets/img/pathlab.png" alt="Precision Pathlab" class="img-fluid"></a>
		
      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="nav-link scrollto" href="https://precisionpathlab.com/">Home</a></li>
          <li><a class="nav-link scrollto active" href="about.php">About Us</a></li>
          <li><a class="nav-link scrollto" href="book-test.php">Book a Test</a></li>
          <li><a class="nav-link scrollto" href="full-body-check-up-in-jaipur.php">Health Packages</a></li>
          <li><a class="nav-link scrollto" href="laboratories.php">Our Laboratories</a></li>
          <li><a class="nav-link scrollto" href="home-collection.php">Home Collection</a></li>
          <li><a class="nav-link scrollto" href="contact.php">Contact</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

<a href="http://175.111.130.182/precision/design/online_lab/default.aspx" target="_blank" class="appointment-btn scrollto"><span class="d-none d-md-inline">Online</span> Report</a>
    </div>
  </header><!-- End Header -->

  <main id="main">

    <!-- ======= Breadcrumbs Section ======= -->
    <section class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h1>About Us</h1>
          <ol>
            <li><a href="index.php">Home</a></li>
            <li>About us</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs Section -->

     <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container-fluid">

        <div class="row">
          <div class="col-xl-5 col-lg-6 d-flex justify-content-center align-items-stretch position-relative">
            <img src="assets/img/about-precision.png" alt="about precision pathlab" width="100%" height="100%" style="padding-top: 50px;"> 
          </div>

          <div class="col-xl-7 col-lg-6 icon-boxes d-flex flex-column align-items-stretch justify-content-center py-5 px-lg-5">
            <h3><b>Precision Path Lab</b> - Experience our quality</h3>
            <p>At Precision Path Lab, our priority is to treat every specimen/sample with equal promptness and expert attention. Needless to say, in critical cases we will provide special and quick service. Every diagnosis is rendered by a certified pathologist/microbiologist with impeccable training and experience, who is committed to your patient's diagnostic and clinical needs.</p>

            <div class="icon-box">
              <div class="icon"><i class="bx bx-fingerprint"></i></div>
              <h4 class="title"><a href="">Pathology </a></h4>
              <p class="description">A pathology test is a test that examines a sample of your body's tissues. Pathology tests give more information about your health. They can be used to help diagnose or monitor a medical condition, screen for certain health conditions to find them early, and monitor your response to medicines and other treatments.</p>
            </div>

            <!--<div class="icon-box">
              <div class="icon"><i class="bx bx-body"></i></div>
              <h4 class="title"><a href="">Radiology</a></h4>
              <p class="description">Radiology, also known as diagnostic imaging, is a series of tests that take pictures or images of parts of the body.</p>
            </div>-->

           <!-- <div class="icon-box">
              <div class="icon"><i class="bx bx-atom"></i></div>
              <h4 class="title"><a href="">Chemical Research </a></h4>
              <p class="description">Blood chemistry tests are blood tests that measure amounts of certain chemicals in a sample of blood. They show how well certain organs are working and can help find abnormalities.</p>
            </div>-->
            

          </div>
        </div>

      </div>
    </section><!-- End About Section -->
	  
	<section id="doctors" class="doctors">
      <div class="container">

        <div class="section-title">
          <h2>Our Management & Doctors</h2>
          <p>Meet our highly experienced & skilled team members.</p>
        </div>

        <div class="row">

          <div class="col-lg-6">
            <div class="member d-flex align-items-start">
              <div class="pic"><img src="assets/img/dr-sameer.jpg" class="img-fluid" alt="Dr Sameer"></div>
              <div class="member-info">
                <h4>Dr. Sameer Agarwal</h4>
                <span>MD</span>
                <p> I have keen interest and expertise in the field of Hematopathology and have worked at Lilavati Hospital, Mumbai. My endeavor is to provide excellent diagnostic services in the field of Hematology and Clinical Pathology.<br><br>


I am a post graduate from Government Hospital, Nagpur. During my post graduation, I won numerous merit certificates for academics, have won state level postgraduate quizzes and have published articles in National and International journals.<br><br>


I am dedicated to offer Jaipur and the entire state of Rajasthan with unmatched quality in the field of diagnostic pathology. I strive for excellence in technical expertise and patient satisfaction.</p>
               
              </div>
            </div>
          </div>

          <div class="col-lg-6 mt-4 mt-lg-0">
            <div class="member d-flex align-items-start">
              <div class="pic"><img src="assets/img/dr-arundhati.jpg" class="img-fluid" alt="Dr Arundati"></div>
              <div class="member-info">
                <h4>Dr. Arundhati Agarwal</h4>
                <span>MD</span>
                <p>I have specialized in histopathology, after my completion of post graduation at Government Hospital, Nagpur. I have worked extensively in Surgical Pathology at Hinduja Hospital, Mumbai. This was followed by my work with the renowned pathologist Dr. Anita Borges in Histopathology and Immunohistochemistry (IHC) at Piramal Diagnostic Centre, Mumbai. I have also worked in Cytology at the reputed Tata Memorial Hospital, Mumbai.<br><br>

					
My experience encompasses all aspects of histopathology including light microscopy, special stains, frozen section and IHC (tumor marker study).<br><br>


With my expertise, I strive to ensure that all your needs are met and you will not have to look beyond Precision Path Lab in the field of Surgical Pathology.</p>
                
              </div>
            </div>
          </div>

        </div><br>

		  
		<div class="row">

          <div class="col-lg-6">
            <div class="member d-flex align-items-start">
              <div class="pic"><img src="assets/img/dr-neetu.jpg" class="img-fluid" alt="Dr Neetu Goyal"></div>
              <div class="member-info">
                <h4>Dr. Neetu Goyal</h4>
                <span>Pathologist</span>
                <p> Dr Neetu Goyal is a highly accomplished medical professional with extensive experience in pathology. She holds an M.D. in Pathology from M.P Shah Medical College in Jamnagar, Guwahati, and an M.B.B.S. from S.N. Medical College in Jodhpur. With years of experience in the field of pathology, Dr Goyal has established herself as a leading expert in the diagnosis and treatment of diseases.<br><br>

 She has worked in various capacities, including as a senior president, in both public and private healthcare institutions, and has played an instrumental role in the development and implementation of pathology services. Dr Goyal is committed to providing compassionate and high-quality care to her patients and is dedicated to advancing the field of pathology through her research and education initiatives</p>
               
              </div>
            </div>
          </div>

			  <div class="col-lg-6 mt-4 mt-lg-0">
	  <div class="member d-flex align-items-start">
		<div class="pic"><img src="assets/img/drpooja.jpeg" class="img-fluid" alt="Dr Pooja"></div>
		<div class="member-info">
		  <h4>Dr. Pooja</h4>
		  <span>Pathologist</span>
		  <p>Dr. Pooja is a Hematopathology specialist with a strong interest and expertise in providing exceptional diagnostic services in Hematology and Clinical Pathology.<br><br>

		  She is a postgraduate from Government College, Agra, and has won several merit certificates for academics, state-level postgraduate quizzes, and published articles in National and International journals. She is dedicated to offering unmatched quality in diagnostic pathology services to Jaipur and the entire state of Rajasthan, with a focus on technical expertise and patient satisfaction.
		  </p>
		</div>
	  </div>
	</div>


        </div>  

      </div>
    </section><!-- End Doctors Section -->
  

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
 <footer id="footer">

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-contact">
            <h3>PRECISION HOUSE</h3>
            <p>
			  <i class="bi bi-geo-alt"></i> :
			  72/2, Shipra Path, Mansarovar<br>
 			  Jaipur 302020 (India)<br><br>
              <i class="bi bi-phone"></i> : +91 8696222281, 8696222678<br>
              <i class="bi bi-envelope"></i> : info@precisionpathlab.com<br>
            </p><br>

			  <h5>Our Timing</h5>
			  <p><b>Monday to Saturday </b><br>
 					8:00 AM to 8:30 PM<br>
				 <b>Sunday</b><br>
					8:00 AM to 2:30 PM</p>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
            <h4>Quick Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="https://precisionpathlab.com/">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="about.php">About us</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="full-body-check-up-in-jaipur.php">Health Packages</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="laboratories.php">Our Laboratories</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Home Collection</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="https://precisionpathlab.com/blog/">Our Blog</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="contact.php">Contact Us</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Our Services</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Pathology Testing</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Microscopic Testing</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">X-Ray</a></li>
			 <li><i class="bx bx-chevron-right"></i> <a href="https://precisionpathlab.com/feedback.php">Feedback</a></li>
            </ul>
          </div>

          <div class="col-lg-4 col-md-6 footer-newsletter">
            <h4 class="text-center">Reach Us</h4>
			  <div class="row">
				  <div class="col-6">
					  <b>Mansarovar</b><br>
			  <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14238.140506209242!2d75.7730997!3d26.8547344!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396db5230f2899a5%3A0xde62d7d0e085d8c3!2sPrecision%20Path%20Lab%20%7C%20Path%20Lab%20in%20Jaipur%20%7C%20Mansarovar!5e0!3m2!1sen!2sin!4v1680676109737!5m2!1sen!2sin" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
           </div>
				   <div class="col-6">
					   <b>Vaishali Nagar</b><br>
			  <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3558.0547805694996!2d75.7413212!3d26.901756499999994!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396db51d7e983483%3A0x80687443d6f95370!2sPrecision%20Path%20Lab%20%7C%20Best%20Diagnostic%20Centre%20%7C%20Full%20body%20Checkup%20in%20Vaishali%20Nagar%2C%20Jaipur!5e0!3m2!1sen!2sin!4v1690892304193!5m2!1sen!2sin" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
           </div>
				  </div>
          </div>

        </div>
      </div>
    </div>

    <div class="container d-md-flex py-4">

     <div class="me-md-auto text-center text-md-start">
        <div class="copyright">
          &copy; Copyright 2025 <strong><span>Precision Path Lab</span></strong>. All Rights Reserved.
        </div>
        <!--<div class="credits">
          Designed by <a href="https://thecogent.in/best-digital-marketing-company-in-jaipur">Digital Marketing Company in Jaipur</a>
        </div>-->
      </div>
      <div class="social-links text-center text-md-right pt-3 pt-md-0">
        <a href="https://www.facebook.com/precisonpathlab" class="facebook"><i class="bx bxl-facebook"></i></a>
        <a href="https://www.instagram.com/precisionpathlab/" class="instagram"><i class="bx bxl-instagram"></i></a>
      </div>
    </div>
  </footer><!-- End Footer -->
	

  <div class="whatsapp-widget">
    <a href="https://wa.me/+917230002896" target="_blank">
      <img src="../img/whatsapp1.png" alt="WhatsApp" width="50px">
	 
		  <b class="text-white">Let's chat</b>
	  
    </a>
	 
  </div>
  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
	<script>
    // Add event listener to show/hide the WhatsApp widget on scroll
    window.addEventListener('scroll', function() {
      var whatsappWidget = document.querySelector('.whatsapp-widget');
      var scrollPosition = window.scrollY || window.pageYOffset;

      if (scrollPosition > 100) {
        whatsappWidget.style.right = '15px';
      } else {
        whatsappWidget.style.right = '-170px';
      }
    });
  </script>

</body>

</html>