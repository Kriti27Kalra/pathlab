<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=0" /> 

  <title>Contact Precision Path Lab - Reach Out for Reliable Diagnostic Services</title>
  <meta content="Contact Precision Path Lab for reliable diagnostic services. Schedule appointments, inquire about services, and get exceptional patient care." name="description">
	<meta property="og:image" content="https://precisionpathlab.com/assets/img/pathlab.png">
  <meta content="" name="keywords">

	
	<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-D8QG004XC3"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-D8QG004XC3');
</script>
  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

 <link rel="canonical" href="https://precisionpathlab.com/contact.php">
  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
	<style>
    /* CSS for the WhatsApp widget */
    .whatsapp-widget {
      position: fixed;
      bottom: 75px;
		width:150px;
		background-color:#00a884;
		border-radius:5%;
      right: -170px; /* Initially hidden */
      z-index: 9999;
      transition: right 0.3s ease-in-out;
    }
    .whatsapp-widget:hover {
      right: 20px; /* Display on hover */
    }
    .whatsapp-widget img {
      width: 50px;
      height: 50px;
    }
  </style>

</head>

<body>

  <!-- ======= Top Bar ======= -->
  <div id="topbar" class="d-flex align-items-center fixed-top">
    <div class="container d-flex justify-content-between">
      <div class="contact-info d-flex align-items-center">
        <i class="bi bi-envelope"></i> <a href="mailto:contact@example.com">info@precisionpathlab.com</a>
        <i class="bi bi-phone"></i> +91-7230002896 
      </div>
      <div class="d-none d-lg-flex social-links align-items-center">
   
        <a href="https://www.facebook.com/precisonpathlab" class="facebook"><i class="bx bxl-facebook"></i></a>
        <a href="https://www.instagram.com/precisionpathlab/" class="instagram"><i class="bi bi-instagram"></i></a>
      </div>
    </div>
  </div>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center">

	<a href="https://precisionpathlab.com/" class="logo me-auto"><img src="assets/img/pathlab.png" alt="Precision Pathlab" class="img-fluid"></a>
		
      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
         <li><a class="nav-link scrollto" href="https://precisionpathlab.com/">Home</a></li>
          <li><a class="nav-link scrollto" href="about.php">About Us</a></li>
          <li><a class="nav-link scrollto" href="book-test.php">Book a Test</a></li>
          <li><a class="nav-link scrollto" href="full-body-check-up-in-jaipur.php">Health Packages</a></li>
          <li><a class="nav-link scrollto" href="laboratories.php">Our Laboratories</a></li>
          <li><a class="nav-link scrollto" href="home-collection.php">Home Collection</a></li>
          <li><a class="nav-link scrollto active" href="contact.php">Contact</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

<a href="http://175.111.130.182/precision/design/online_lab/default.aspx" target="_blank" class="appointment-btn scrollto"><span class="d-none d-md-inline">Online</span> Report</a>
    </div>
  </header><!-- End Header -->

  <main id="main">

    <!-- ======= Breadcrumbs Section ======= -->
    <section class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Contact Us</h2>
          <ol>
            <li><a href="index.php">Home</a></li>
            <li>Contact us</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs Section -->

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container">

        <div class="section-title">
          <h2>Reach us - Precision Path Lab</h2>
        </div>
      </div>

      <div class="container">
        <div class="row mt-5">

          <div class="col-lg-4">
            <div class="info">
              <div class="address">
                <i class="bi bi-geo-alt"></i>
                <h4>Address:</h4>
                <p><b>PRECISION HOUSE</b><br>
					72/2, Shipra Path, Mansarovar<br>
					Jaipur-302020 (Rajasthan) INDIA</p>
              </div>

              <div class="email">
                <i class="bi bi-envelope"></i>
                <h4>Email:</h4>
                <p>info@precisionpathlab.com</p>
              </div>

              <div class="phone">
                <i class="bi bi-phone"></i>
                <h4>Call:</h4>
                <p>+91-141-2786337, +91-8696222281</p>
              </div>

            </div>

          </div>
			
						
          <div class="col-lg-8 mt-5 mt-lg-0">

            <form method="post" action="https://precisionpathlab.com/contact.php#contact">
              <div class="row">
                <div class="col-md-6 form-group">
                  <input type="text" name="name" class="form-control txtNumeric1" id="name" placeholder="Your Name" required>
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" required>
                </div>
              </div>
				 <div class="form-group mt-3">
                <input type="text" class="form-control numbersOnly" maxlength="10" minlength="10" name="phone" id="phone" placeholder="Phone number" required>
              </div>
              <div class="form-group mt-3">
                <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" required>
              </div>
              <div class="form-group mt-3">
                <textarea class="form-control" name="message" rows="5" placeholder="Message" required></textarea>
              </div>
               <div class="mb-3 text-center">
            <b style="color:green;"></b>
			  
          </div>
              <div class="text-center"><button type="submit" name="submit2" class="btn btn-primary">Send Message</button></div>
            </form>

          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->


  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-contact">
            <h3>PRECISION HOUSE</h3>
            <p>
			  <i class="bi bi-geo-alt"></i> :
			  72/2, Shipra Path, Mansarovar<br>
 			  Jaipur 302020 (India)<br><br>
              <i class="bi bi-phone"></i> : +91 8696222281, 8696222678<br>
              <i class="bi bi-envelope"></i> : info@precisionpathlab.com<br>
            </p><br>

			  <h5>Our Timing</h5>
			  <p><b>Monday to Saturday </b><br>
 					8:00 AM to 8:30 PM<br>
				 <b>Sunday</b><br>
					8:00 AM to 2:30 PM</p>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
            <h4>Quick Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="https://precisionpathlab.com/">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="about.php">About us</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="full-body-check-up-in-jaipur.php">Health Packages</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="laboratories.php">Our Laboratories</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Home Collection</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="https://precisionpathlab.com/blog/">Our Blog</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="contact.php">Contact Us</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Our Services</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Pathology Testing</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Microscopic Testing</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">X-Ray</a></li>
			 <li><i class="bx bx-chevron-right"></i> <a href="https://precisionpathlab.com/feedback.php">Feedback</a></li>
            </ul>
          </div>

          <div class="col-lg-4 col-md-6 footer-newsletter">
            <h4 class="text-center">Reach Us</h4>
			  <div class="row">
				  <div class="col-6">
					  <b>Mansarovar</b><br>
			  <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14238.140506209242!2d75.7730997!3d26.8547344!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396db5230f2899a5%3A0xde62d7d0e085d8c3!2sPrecision%20Path%20Lab%20%7C%20Path%20Lab%20in%20Jaipur%20%7C%20Mansarovar!5e0!3m2!1sen!2sin!4v1680676109737!5m2!1sen!2sin" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
           </div>
				   <div class="col-6">
					   <b>Vaishali Nagar</b><br>
			  <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3558.0547805694996!2d75.7413212!3d26.901756499999994!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396db51d7e983483%3A0x80687443d6f95370!2sPrecision%20Path%20Lab%20%7C%20Best%20Diagnostic%20Centre%20%7C%20Full%20body%20Checkup%20in%20Vaishali%20Nagar%2C%20Jaipur!5e0!3m2!1sen!2sin!4v1690892304193!5m2!1sen!2sin" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
           </div>
				  </div>
          </div>

        </div>
      </div>
    </div>

    <div class="container d-md-flex py-4">

     <div class="me-md-auto text-center text-md-start">
        <div class="copyright">
          &copy; Copyright 2025 <strong><span>Precision Path Lab</span></strong>. All Rights Reserved.
        </div>
        <!--<div class="credits">
          Designed by <a href="https://thecogent.in/best-digital-marketing-company-in-jaipur">Digital Marketing Company in Jaipur</a>
        </div>-->
      </div>
      <div class="social-links text-center text-md-right pt-3 pt-md-0">
        <a href="https://www.facebook.com/precisonpathlab" class="facebook"><i class="bx bxl-facebook"></i></a>
        <a href="https://www.instagram.com/precisionpathlab/" class="instagram"><i class="bx bxl-instagram"></i></a>
      </div>
    </div>
  </footer><!-- End Footer -->

   <div class="whatsapp-widget">
    <a href="https://wa.me/+917230002896" target="_blank">
      <img src="../img/whatsapp1.png" alt="WhatsApp" width="50px">
	 
		  <b class="text-white">Let's chat</b>
	  
    </a>
	 
  </div>
  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>


  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
	<script>
    // Add event listener to show/hide the WhatsApp widget on scroll
    window.addEventListener('scroll', function() {
      var whatsappWidget = document.querySelector('.whatsapp-widget');
      var scrollPosition = window.scrollY || window.pageYOffset;

      if (scrollPosition > 100) {
        whatsappWidget.style.right = '15px';
      } else {
        whatsappWidget.style.right = '-170px';
      }
    });
  </script>
	 <script type="text/javascript" src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
	<script>
  $(function() {

  $('.txtNumeric1').keydown(function (e) {
  
    if (e.shiftKey || e.ctrlKey || e.altKey) {
    
      e.preventDefault();
      
    } else {
    
      var key = e.keyCode;
      
      if (!((key == 8) || (key == 32) || (key == 46) || (key >= 35 && key <= 40) || (key >= 65 && key <= 90))) {
      
        e.preventDefault();
        
      }

    }
    
  });
  
});
</script>
<script type="text/javascript">
         
        jQuery(document).ready(function () {    
 
            jQuery( '.numbersOnly' ).keypress(function (e) {   
  
                var charCode = (e.which) ? e.which : event.keyCode    
                if (String.fromCharCode(charCode).match(/[^0-9]/g))    
                    return false;                        
            });    
 
        });   
  
    </script>

</body>

</html>