<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=0" /> 

  <title>Book Full Body Checkup in Jaipur @799 Only</title>
  <meta content="Get a comprehensive full body checkup in Jaipur starting from @799 INR. Our health checkup packages include a range of tests to assess your overall health. Book an appointment today!" name="description">
  <meta content="" name="keywords">
	<meta property="og:image" content="https://precisionpathlab.com/assets/img/pathlab.png">
	
	<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-D8QG004XC3"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-D8QG004XC3');
</script>

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

 <link rel="canonical" href="https://precisionpathlab.com/full-body-check-up-in-jaipur.php">
  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
	<style>
    /* CSS for the WhatsApp widget */
    .whatsapp-widget {
      position: fixed;
      bottom: 75px;
		width:150px;
		background-color:#00a884;
		border-radius:5%;
      right: -170px; /* Initially hidden */
      z-index: 9999;
      transition: right 0.3s ease-in-out;
    }
    .whatsapp-widget:hover {
      right: 20px; /* Display on hover */
    }
    .whatsapp-widget img {
      width: 50px;
      height: 50px;
    }
		 .btn2:hover .btn1{
		color:blue;
		 background-color:white;
	 }
  </style>
	
	<script type="application/ld+json">
  {
    "@context"      : "https://schema.org",
    "@type"         : "Review",
    "itemReviewed"  : {
        "@type"     : "LocalBusiness",
        "address"   : {
            "@type"             : "PostalAddress",
            "addressLocality"   : "Jaipur"
        },
        "name"          :   "Full Body Checkup in Jaipur",
        "description"   : "Get a comprehensive full body checkup in Jaipur starting from @799 INR. Our health checkup packages include a range of tests to assess your overall health. Book an appointment today!",
        "URL"           : "https://www.precisionpathlab.com/full-body-check-up-in-jaipur.php",
        "Image"         : "hhttps://www.precisionpathlab.com/assets/img/pathlab.png",
        "priceRange"    : "20 Tests @ ₹799",
        "telephone"     : "+917230002896"
    },
    "author": {
        "@type" : "Organization",
        "name"  : "Precision Path Lab",
        "URL"   : "https://www.precisionpathlab.com/"
    },
    "ReviewRating"      : {
        "@type"         : "AggregateRating",
        "bestRating"    : "5",
        "ratingCount"   : 100012,
        "ratingValue"   : 4.5,
        "itemReviewed"  : {
            "@type"     : "Thing",
            "name"      : "ServiceReview"
        }
    }
}
</script>
	<script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [{
        "@type": "ListItem",
        "position": 1,
        "name": "Pathology Lab in Jaipur",
        "item": "https://www.precisionpathlab.com/"
      },{
        "@type": "ListItem",
        "position": 2,
        "name": "Full Body Checkup in Jaipur",
        "item": "https://www.precisionpathlab.com/full-body-check-up-in-jaipur.php"
      }]
    }
</script>
	
 
</head>

<body>

  <!-- ======= Top Bar ======= -->
  <div id="topbar" class="d-flex align-items-center fixed-top">
    <div class="container d-flex justify-content-between">
      <div class="contact-info d-flex align-items-center">
        <i class="bi bi-envelope"></i> <a href="mailto:contact@example.com">info@precisionpathlab.com</a>
        <i class="bi bi-phone"></i> +91-7230002896 
      </div>
      <div class="d-none d-lg-flex social-links align-items-center">

        <a href="https://www.facebook.com/precisonpathlab" class="facebook"><i class="bx bxl-facebook"></i></a>
        <a href="https://www.instagram.com/precisionpathlab/" class="instagram"><i class="bi bi-instagram"></i></a>
      </div>
    </div>
  </div>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center">

		<a href="https://precisionpathlab.com/" class="logo me-auto"><img src="assets/img/pathlab.png" alt="Precision Pathlab" class="img-fluid"></a>

		<nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="nav-link scrollto" href="https://precisionpathlab.com/">Home</a></li>
          <li><a class="nav-link scrollto" href="about.php">About Us</a></li>
          <li><a class="nav-link scrollto" href="book-test.php">Book a Test</a></li>
          <li><a class="nav-link scrollto active" href="full-body-check-up-in-jaipur.php">Health Packages</a></li>
          <li><a class="nav-link scrollto" href="laboratories.php">Our Laboratories</a></li>
          <li><a class="nav-link scrollto" href="home-collection.php">Home Collection</a></li>
          <li><a class="nav-link scrollto" href="contact.php">Contact</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

<a href="http://175.111.130.182/precision/design/online_lab/default.aspx" target="_blank" class="appointment-btn scrollto"><span class="d-none d-md-inline">Online</span> Report</a>
    </div>
  </header><!-- End Header -->

   <!-- ======= Breadcrumbs Section ======= -->
    <section class="breadcrumbs">
      <div class="container">
	<div class="row">
        <div class="col-12">
          <h1>Full Body & Health Checkup in Jaipur </h1>
			<b>Get comprehensive  Health Checkup & Full Body Checkup in Jaipur at Precision Pathlab, ensuring complete well-being and accurate diagnostic results.</b><br>
          <ol style="float:right;">
            <li><a style="color:black;" href="index.php">Home</a></li>
            <li style="color:blue;">Health Checkup</li>
          </ol>
			
        </div>
		  </div>
      </div>
    </section><!-- End Breadcrumbs Section -->

  <main id="main">


    <!-- ======= Services Section ======= -->
    <section id="services" class="services">
      <div class="container">

        <div class="section-title">
          <h2>Complete Full Body Checkup Packages in Jaipur</h2><br>

          <p>In today's fast-paced world, where time seems to be slipping away all the time, taking care of our health frequently takes a back seat. However, disregarding our well-being might have major long-term effects. Regular checkups are vital for staying on top of our health. The Full Body Checkup in Jaipur, a holistic examination that assesses numerous areas of our well-being, is one such comprehensive health assessment.<br>


Residents of the lively city of Jaipur have access to cutting-edge healthcare facilities that provide excellent Full Body Checkups. This article intends to shine a light on the importance of a best Full Body Checkup in Jaipur and emphasize the advantages it provides for people of all ages.</p>
        </div>

        <div class="row">
			
          <div class="col-lg-3 col-md-6 d-flex align-items-stretch box btn2">
		   <div class="ribbon ribbon-top-left"><span>Rs. 799/-</span></div>
            <div class="icon-box">
              <div class="icon"><img src="assets/img/icon1.png" width="50" height="50"></div>
              <h4><a href="">PACKAGE-1</a></h4>
              <p>Blood Sugar (F), HbA1c, Creatinine, Calcium, Lipid Profile, Complete Blood Count (CBC), Urine Examination</p>
				<br>
			  <a href="#appointment" class="appointment-btn scrollto btn1"><span class="d-inline">Book</span> Test</a>
            </div>
			  
          </div>

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch mt-4 mt-md-0 box btn2" >
		  <div class="ribbon ribbon-top-left"><span>Rs. 1599/-</span></div>
            <div class="icon-box">
              <div class="icon"><img src="assets/img/icon2.png" width="50" height="50"></div>
              <h4><a href="">PACKAGE-2</a></h4>
              <p>Blood Sugar (F), HbA1c, Creatinine, Calcium, Lipid Profile, CBC, Urine Examination, Vitamin B12, Vitamin D3, Thyroid Profile</p>
				<br>
			  <a href="#appointment" class="appointment-btn scrollto btn1"><span class="d-inline">Book</span> Test</a>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch mt-4 mt-lg-0 box btn2">
            <div class="ribbon ribbon-top-left"><span>Rs. 2099/-</span></div>
            <div class="icon-box">
              <div class="icon"><img src="assets/img/icon3.png" width="50" height="50"></div>
              <h4><a href="">PACKAGE-3</a></h4>
              <p>Blood Sugar (F), Creatinine, Lipid Profile, CBC, ESR, Urine Routine, Vitamin B12, Vitamin D3, Thyroid Profile ECG, KFT, LFT, X-Ray Chest</p>
			  <br>
			  <a href="#appointment" class="appointment-btn scrollto btn1"><span class="d-inline">Book</span> Test</a>
            </div>
          </div>
		  
		  <div class="col-lg-3 col-md-6 d-flex align-items-stretch mt-4 mt-lg-0 box btn2">
            <div class="ribbon ribbon-top-left"><span>Rs. 3599/-</span></div>
            <div class="icon-box">
              <div class="icon"><img src="assets/img/icon4.png" width="50" height="50"></div>
              <h4><a href="">PACKAGE-4</a></h4>
              <p>Blood Sugar (F), Creatinine, Lipid Profile, CBC, ESR, Ferritin, HbA1c, Iron, Urine Routine, Vitamin B12, Vitamin D3, Thyroid Profile, Stool Examination, KFT, LFT, TIBC, Transferrin Saturation, X-Ray Chest, ECG, USG Whole Abdomen</p><br>

			  <a href="#appointment" class="appointment-btn scrollto btn1"><span class="d-inline">Book</span> Test</a>
            </div>
          </div>

        </div>
      </div>
    </section><!-- End Services Section -->

	 <section id="services" class="services">
	   <div class="container">
	  <div class="section-title">
          <h2>Full Body Checkup Price In Jaipur?</h2><br>
          <div class="col-12">
				<h5><b>Please find full Health Packages details below:</b></h5><br>

	<table class="table table-light table-striped">
  <thead>
    <tr>
      <th scope="col">S.No</th>
      <th scope="col">Packages:</th>
      <th scope="col">Included Tests:</th>
      <th scope="col">Price:</th>
		<th scope="col"> </th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td> Package-1</td>
      <td>Blood Sugar (F), HbA1c, Creatinine, Calcium, Lipid Profile, Complete Blood Count (CBC), Urine Examination</td>
	  <td> Rs. 799/- </td>
		<td> <a href="#appointment">Book Now</a></td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Package-2</td>
      <td>Blood Sugar (F), HbA1c, Creatinine, Calcium, Lipid Profile, CBC, Urine Examination, Vitamin B12, Vitamin D3, Thyroid Profile</td>
       <td> Rs. 1599/- </td>
		<td> <a href="#appointment">Book Now</a></td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Package-3</td>
      <td>Blood Sugar (F), Creatinine, Lipid Profile, CBC, ESR, Urine Routine, Vitamin B12, Vitamin D3, Thyroid Profile ECG, KFT, LFT, X-Ray Chest</td>
	  <td> Rs. 2099/- </td>
	   <td> <a href="#appointment">Book Now</a></td>
	  </tr>
	 <tr>
      <th scope="row">4</th>
      <td>Package-4</td>
      <td>Blood Sugar (F), Creatinine, Lipid Profile, CBC, ESR, Ferritin, HbA1c, Iron, Urine Routine, Vitamin B12, Vitamin D3, Thyroid Profile, Stool Examination, KFT, LFT, TIBC, Transferrin Saturation, X-Ray Chest, ECG, USG Whole Abdomen</td>
	  <td> Rs. 3599/- </td>
	  <td> <a href="#appointment">Book Now</a></td>
	  </tr>
      
	 
  </tbody>
</table>
			</div>
        </div>
		 </div>
	  </section>
	  
	  <section id="services" class="services" style="padding-top: 20px!important;">
		  <div class="container">
		   <div class="row">
			  <div class="col-xl-5 col-lg-6 d-flex justify-content-center align-items-stretch position-relative">
				<img src="assets/img/full-check-up.png" width=100% height="100%"> 
			  </div>
			   <div class="col-xl-7 col-lg-6 icon-boxes d-flex flex-column align-items-stretch justify-content-center py-5 px-lg-5">
				  <div class="section-title">
					 <h2>What is a full body checkup?</h2>
					  <p>A full body checkup, also known as a comprehensive health checkup or an annual physical examination, is a thorough medical assessment that evaluates a person's overall health status. It involves a series of tests, screenings, and consultations with healthcare professionals to assess various aspects of a person's physical and mental well-being.<br>
					  The specific components of a Full Body Checkup in Jaipur may vary depending on factors such as age, gender, medical history, and individual preferences</p>
				   </div>
			   </div>  
		  </div>
		   <div class="row">
			   <div class="section-title">
			    <h2> Benefits of a Full body checkup?</h2>
				   <p>Regular health checkups are crucial for maintaining overall well-being. A full body checkup, also known as a comprehensive health screening, is a proactive approach to monitoring your health and detecting potential issues at an early stage. In this blog, we will explore the numerous benefits of undergoing a Full Body Checkup in Jaipur and why it should be a priority for everyone.</p>
				   <p><br>
					  
				  <h3 style="text-align: left"> 1. Early Detection and Prevention:</h3>
				   <p style="text-align: left">
One of the primary advantages of health checkup packages in Jaipur is the early detection of diseases. Many serious health conditions, such as heart disease, diabetes, cancer, and hypertension, may not exhibit symptoms in their initial stages. By undergoing regular screenings, you increase the chances of detecting these conditions early, when they are easier to manage and treat effectively. Early intervention often leads to improved outcomes and a higher chance of recovery.<br>
				   </p><br>

<h3 style="text-align: left">2. Comprehensive Assessment: </h3>
<p style="text-align: left">
A health checkup package in Jaipur offers a comprehensive evaluation of your overall health. It typically includes a range of tests and screenings, such as blood tests, imaging scans, cardiovascular assessments, and specialized examinations. These evaluations provide insights into various aspects of your health, including cholesterol levels, blood sugar levels, organ function, bone density, and more. This comprehensive assessment helps identify any underlying issues that might otherwise go unnoticed.<br>
				   </p><br>

<h3 style="text-align: left">3. Personalized Healthcare:</h3>
<p style="text-align: left">
Health checkup packages in Jaipur often involve consultations with healthcare professionals who review your test results and provide personalized advice and guidance. They can offer recommendations for lifestyle modifications, prescribe appropriate medications if needed, and suggest preventive measures tailored to your specific health needs. This personalized approach helps you make informed decisions about your health and empowers you to take control of your well-being.<br>
				   </p><br>

<h3 style="text-align: left">4. Peace of Mind:</h3>
<p style="text-align: left">
Undergoing a full body checkup provides peace of mind. Knowing that you have taken proactive steps to monitor your health and detect potential problems early offers reassurance. It allows you to stay informed about your body's functioning and take necessary actions, if required, to maintain or improve your overall well-being.<br>
				   </p><br>

<h3 style="text-align: left">5. Motivation for Healthy Habits:</h3>
<p style="text-align: left">
Health checkup packages in Jaipur can serve as a powerful motivator to adopt a healthier lifestyle. If the results indicate areas of concern, it can inspire you to make positive changes in your daily habits. Whether it's improving your diet, engaging in regular exercise, managing stress, or quitting harmful habits like smoking or excessive alcohol consumption, the information gained from a full body checkup can encourage you to prioritize your health and well-being.<br>
				   </p><br>

<h3 style="text-align: left">6.Time and Cost Efficiency:</h3>
<p style="text-align: left">
Instead of visiting multiple specialists for different health concerns, a full body checkup allows you to have all the necessary tests done in a single visit. This saves time and streamlines the process, ensuring you receive a comprehensive overview of your health efficiently. Additionally, by detecting potential health issues early, you may prevent the need for more extensive and expensive treatments in the future, making it a cost-effective approach to healthcare.
				   </p>
				   
			   </div>
			</div> 
			  <div class="row">
		   
				  <div class="section-title">
					 <h2>Conclusion</h2>
					  <p>A full body checkup is a proactive step towards maintaining optimal health and preventing potential health issues. The benefits of early detection, personalized healthcare, comprehensive assessment, peace of mind, motivation for healthy habits, and time and cost efficiency make it a crucial aspect of proactive healthcare. By prioritizing regular full body checkups, you empower yourself to lead a healthier life and take control of your well-being. Remember, your health is your most valuable asset, and investing in it through regular checkups is a small price to pay for a lifetime of good health. </p>
				   </div>
			     
		     </div>
			  
		  </div>	  
	  </section>
	  
	  <section id="services" class="services" style="padding-top: 20px!important;">
		  <script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [{
    "@type": "Question",
    "name": "How much does a full body checkup cost in Jaipur?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "The cost of a health checkup packages in jaipur can vary depending on various factors such as the medical facility or clinic you choose, the specific tests included in the checkup package, and any additional services or consultations included. Additionally, prices can change over time."
    }
  },{
    "@type": "Question",
    "name": "What is included in a full body checkup?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "A health checkup packages in jaipur typically includes a comprehensive evaluation of your overall health and well-being. The specific tests and examinations included may vary depending on the healthcare provider or the package you choose. The specific tests included in a full body checkup can vary depending on factors such as age, gender, and personal health history. However, some common tests often included are blood tests (such as complete blood count, lipid profile, liver and kidney function tests), urine analysis, chest X-ray, electrocardiogram (ECG), ultrasound scans, and various screenings (such as for diabetes, cholesterol levels, cancer, and bone health)."
    }
  },{
    "@type": "Question",
    "name": "Is a full body checkup useful?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Yes, a full body checkup can be very useful for several reasons. Early detection of diseases:
Regular checkups can help identify risk factors and provide an opportunity for healthcare professionals to offer preventive advice and interventions.   A full body checkup provides a comprehensive evaluation of your overall health, including various aspects such as blood tests, physical examinations, and imaging tests."
    }
  },{
    "@type": "Question",
    "name": "How do I choose a health checkup?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Choosing a health checkup involves considering several factors to ensure that it aligns with your specific needs and health goal. Determine the specific objectives you want to achieve through the health checkup. Consult with a healthcare professional: Schedule an appointment with your primary care physician or a healthcare professional to discuss your health concerns, medical history, and any specific risk factors. They can provide valuable insights and recommend tests based on your individual needs."
    }
  },{
    "@type": "Question",
    "name": "Why choose a full body checkup in Jaipur from Precision path lab?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "There are several compelling reasons to choose Precision Path Lab in Jaipur for your full body checkup. Precision Path Lab has established a strong reputation as a trusted healthcare provider, offering a comprehensive range of diagnostic services with a focus on precision and accuracy.
First and foremost, Precision Path Lab boasts a team of highly skilled and experienced healthcare professionals. With their expertise, you can have confidence in the reliability and precision of your full body checkup.
 
Precision Path Lab takes pride in offering a comprehensive examination that covers a wide range of tests and screenings. Their full body checkup package is designed to assess various aspects of your health, including blood tests, imaging studies, organ function evaluations, and other crucial parameters. This comprehensive approach ensures that no potential health issue goes undetected, allowing for early intervention and preventive measures."
    }
  },{
    "@type": "Question",
    "name": "Why are our Full Body Checkup services the best and most accurate in Jaipur?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Our Full Body Checkup services are considered the best and most accurate in Jaipur for several reasons. We have invested in state-of-the-art diagnostic technology and equipment. Our facility is equipped with the latest machinery and instruments, ensuring precise and reliable test results. By utilizing advanced technology, we can detect even the slightest abnormalities and provide a comprehensive assessment of your health. Our team consists of highly qualified and experienced healthcare professionals, including doctors, specialists, and technicians."
    }
  }]
}
</script>
		  <div class="container">
			  <div class="section-title">
				<h2>FAQ’s for full body checkup in Jaipur</h2>
			  </div>	  
		    <div class="row">
	   		  <div class="accordion" id="accordionExample">
  <div class="accordion-item">
    <h3 class="accordion-header">
      <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
       1. How much does a full body checkup cost in Jaipur?  
      </button>
    </h3>
    <div id="collapseOne" class="accordion-collapse collapse show" data-bs-parent="#accordionExample">
      <div class="accordion-body">
        <strong>The cost of a health checkup packages in jaipur can vary depending on various factors such as the medical facility or clinic you choose, the specific tests included in the checkup package, and any additional services or consultations included. Additionally, prices can change over time.</strong>
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h3 class="accordion-header">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
        2. What is included in a full body checkup? 
      </button>
    </h3>
    <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
      <div class="accordion-body">
        <strong>A health checkup packages in jaipur typically includes a comprehensive evaluation of your overall health and well-being. The specific tests and examinations included may vary depending on the healthcare provider or the package you choose. The specific tests included in a full body checkup can vary depending on factors such as age, gender, and personal health history. However, some common tests often included are blood tests (such as complete blood count, lipid profile, liver and kidney function tests), urine analysis, chest X-ray, electrocardiogram (ECG), ultrasound scans, and various screenings (such as for diabetes, cholesterol levels, cancer, and bone health).</strong>
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h3 class="accordion-header">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
       3. Is a full body checkup useful? 
      </button>
    </h3>
    <div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
      <div class="accordion-body">
        <strong>Yes, a full body checkup can be very useful for several reasons. Early detection of diseases:
Regular checkups can help identify risk factors and provide an opportunity for healthcare professionals to offer preventive advice and interventions.   A full body checkup provides a comprehensive evaluation of your overall health, including various aspects such as blood tests, physical examinations, and imaging tests.</strong>
      </div>
    </div>
  </div>
	   <div class="accordion-item">
    <h3 class="accordion-header">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
        4. How do I choose a health checkup?
      </button>
    </h3>
    <div id="collapseFour" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
      <div class="accordion-body">
        <strong>Choosing a health checkup involves considering several factors to ensure that it aligns with your specific needs and health goal. Determine the specific objectives you want to achieve through the health checkup. Consult with a healthcare professional: Schedule an appointment with your primary care physician or a healthcare professional to discuss your health concerns, medical history, and any specific risk factors. They can provide valuable insights and recommend tests based on your individual needs.</strong>
      </div>
    </div>
  </div>
		    <div class="accordion-item">
    <h3 class="accordion-header">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
       5. Why choose a full body checkup in Jaipur from Precision path lab? 
      </button>
    </h3>
    <div id="collapseFive" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
      <div class="accordion-body">
        <strong>There are several compelling reasons to choose Precision <a href="https://www.precisionpathlab.com/">Path Lab in Jaipur </a>for your full body checkup. Precision Path Lab has established a strong reputation as a trusted healthcare provider, offering a comprehensive range of diagnostic services with a focus on precision and accuracy.<br>

First and foremost, Precision Path Lab boasts a team of highly skilled and experienced healthcare professionals. With their expertise, you can have confidence in the reliability and precision of your full body checkup.<br>
 
Precision Path Lab takes pride in offering a comprehensive examination that covers a wide range of tests and screenings. Their full body checkup package is designed to assess various aspects of your health, including blood tests, imaging studies, organ function evaluations, and other crucial parameters. This comprehensive approach ensures that no potential health issue goes undetected, allowing for early intervention and preventive measures.</strong>
      </div>
    </div>
  </div>
				 <div class="accordion-item">
    <h3 class="accordion-header">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
         6. Why are our Full Body Checkup services the best and most accurate in Jaipur? 
      </button>
    </h3>
    <div id="collapseSix" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
      <div class="accordion-body">
        <strong>Our Full Body Checkup services are considered the best and most accurate in Jaipur for several reasons. We have invested in state-of-the-art diagnostic technology and equipment. Our facility is equipped with the latest machinery and instruments, ensuring precise and reliable test results. By utilizing advanced technology, we can detect even the slightest abnormalities and provide a comprehensive assessment of your health. Our team consists of highly qualified and experienced healthcare professionals, including doctors, specialists, and technicians.</strong>
      </div>
    </div>
  </div>
					 
</div>
		    </div>
	     </div>
	  </section>
	  
	  
    <!-- ======= Appointment Section ======= -->
	  <section id="appointment" class="appointment section-bg">
      <div class="container-fluid">

        <div class="row">
          <div class="col-xl-5 col-lg-6 d-flex justify-content-center align-items-stretch position-relative">
            <img src="assets/img/test.png" width=100% height="100%"> 
          </div>

          <div class="col-xl-7 col-lg-6 icon-boxes d-flex flex-column align-items-stretch justify-content-center py-5 px-lg-5">
          <div class="section-title">
			  <h2>Make an appointment</h2>
			</div>
			  		 <form method="post" action="https://precisionpathlab.com/full-body-check-up-in-jaipur.php#appointment" >
          <div class="row">
            <div class="col-md-4 form-group">
              <input type="text" name="name" class="form-control" id="name" placeholder="Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars" required>
              <div class="validate"></div>
            </div>
            <div class="col-md-4 form-group mt-3 mt-md-0">
              <input type="email" class="form-control" name="email" id="email" placeholder="Email Id" data-rule="email" data-msg="Please enter a valid email" required>
              <div class="validate"></div>
            </div>
            <div class="col-md-4 form-group mt-3 mt-md-0">
              <input type="tel" class="form-control" name="phone" id="phone" placeholder="Phone Number" data-rule="minlen:4" data-msg="Please enter at least 4 chars" required>
              <div class="validate"></div>
            </div>
          </div>
        

          <div class="form-group mt-3">
            <textarea class="form-control" name="message" rows="5" placeholder="Message (Optional)"></textarea>
            <div class="validate"></div>
          </div>
            <div class="mb-3 text-center">
            <b style="color:green;"></b>
			  
          </div>
          <div class="text-center"><button type="submit" class="btn btn-primary" name="submit2">Book Test</button></div>
        </form>
            

          </div>
        </div>

      </div>
    </section>
    <!-- End Appointment Section -->
	  
  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-contact">
            <h3>PRECISION HOUSE</h3>
            <p>
			  <i class="bi bi-geo-alt"></i> :
			  72/2, Shipra Path, Mansarovar<br>
 			  Jaipur 302020 (India)<br><br>
              <i class="bi bi-phone"></i> : +91 8696222281, 8696222678<br>
              <i class="bi bi-envelope"></i> : info@precisionpathlab.com<br>
            </p><br>

			  <h5>Our Timing</h5>
			  <p><b>Monday to Saturday </b><br>
 					8:00 AM to 8:30 PM<br>
				 <b>Sunday</b><br>
					8:00 AM to 2:30 PM</p>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
            <h4>Quick Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="https://precisionpathlab.com/">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="about.php">About us</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="full-body-check-up-in-jaipur.php">Health Packages</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="laboratories.php">Our Laboratories</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Home Collection</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="https://precisionpathlab.com/blog/">Our Blog</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="contact.php">Contact Us</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Our Services</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Pathology Testing</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Microscopic Testing</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">X-Ray</a></li>
			 <li><i class="bx bx-chevron-right"></i> <a href="https://precisionpathlab.com/feedback.php">Feedback</a></li>
            </ul>
          </div>

          <div class="col-lg-4 col-md-6 footer-newsletter">
            <h4 class="text-center">Reach Us</h4>
			  <div class="row">
				  <div class="col-6">
					  <b>Mansarovar</b><br>
			  <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14238.140506209242!2d75.7730997!3d26.8547344!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396db5230f2899a5%3A0xde62d7d0e085d8c3!2sPrecision%20Path%20Lab%20%7C%20Path%20Lab%20in%20Jaipur%20%7C%20Mansarovar!5e0!3m2!1sen!2sin!4v1680676109737!5m2!1sen!2sin" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
           </div>
				   <div class="col-6">
					   <b>Vaishali Nagar</b><br>
			  <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3558.0547805694996!2d75.7413212!3d26.901756499999994!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396db51d7e983483%3A0x80687443d6f95370!2sPrecision%20Path%20Lab%20%7C%20Best%20Diagnostic%20Centre%20%7C%20Full%20body%20Checkup%20in%20Vaishali%20Nagar%2C%20Jaipur!5e0!3m2!1sen!2sin!4v1690892304193!5m2!1sen!2sin" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
           </div>
				  </div>
          </div>

        </div>
      </div>
    </div>

    <div class="container d-md-flex py-4">

      <div class="me-md-auto text-center text-md-start">
        <div class="copyright">
          &copy; Copyright 2025 <strong><span>Precision Path Lab</span></strong>. All Rights Reserved.
        </div>
        <!--<div class="credits">
          Designed by <a href="https://thecogent.in/best-digital-marketing-company-in-jaipur">Digital Marketing Company in Jaipur</a>
        </div>-->
      </div>
      <div class="social-links text-center text-md-right pt-3 pt-md-0">
        <a href="https://www.facebook.com/precisonpathlab" class="facebook"><i class="bx bxl-facebook"></i></a>
        <a href="https://www.instagram.com/precisionpathlab/" class="instagram"><i class="bx bxl-instagram"></i></a>
      </div>
    </div>
  </footer><!-- End Footer -->

  
  <div class="whatsapp-widget">
    <a href="https://wa.me/+917230002896" target="_blank">
      <img src="../img/whatsapp1.png" alt="WhatsApp" width="50px">
	 
		  <b class="text-white">Let's chat</b>
	  
    </a>
	 
  </div>
  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>




  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
	<script>
function tabSwithch() {
  location.replace("/book-test.html#packages")
}
</script>
	<script>
    // Add event listener to show/hide the WhatsApp widget on scroll
    window.addEventListener('scroll', function() {
      var whatsappWidget = document.querySelector('.whatsapp-widget');
      var scrollPosition = window.scrollY || window.pageYOffset;

      if (scrollPosition > 100) {
        whatsappWidget.style.right = '15px';
      } else {
        whatsappWidget.style.right = '-170px';
      }
    });
  </script>

</body>

</html>