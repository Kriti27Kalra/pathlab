<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=0" /> 
	
  <title>Precision Path Lab: Pathology Labs in Jaipur</title>
  <meta name="description" content="Precision Path Lab: Trusted pathology labs in Jaipur. Accurate diagnostics, personalized care. Visit us for reliable results." >
  <meta content="" name="keywords">
	<meta property="og:title" content="Precision Path Lab | Best Pathlab in Jaipur">
<meta property="og:site_name" content="Precision Pathlab">
<meta property="og:url" content="https://precisionpathlab.com/">
<meta property="og:description" content="Precision Pathlab is the trusted diagnostic centre in Jaipur that offers blood tests, urine tests, and more. Visit our website to schedule an appointment today">
<meta property="og:type" content="website">
<meta property="og:image" content="https://precisionpathlab.com/assets/img/pathlab.png">
	<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-D8QG004XC3"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}

  gtag('config', 'G-D8QG004XC3');
</script>
	
	
	<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-N2ZCPDFD');</script>
<!-- End Google Tag Manager -->
	
	<meta name="google-site-verification" content="gqGT26KgS4iT71WHYVyhON2uXViTA7UCQKQ7mlCaB_k" /> 

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">
 <link rel="canonical" href="https://precisionpathlab.com/" />
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
 <style>
	
	 .emploayee-number{
		 position: absolute;
    top: -25px;
    left: 50%;
    transform: translateX(-50%);
    font-size: 20px!important;
    background: #1977cc;
    color: #e0dada;
    border-radius: 50px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 48px;
  	z-index:1;
    font-weight: 800;
    height: 48px;
	 }
	 
	 /*review slider*/
	 
	   .owl-carousel {
      position:relative;
      width:80%;
      height:100%;
      margin:0 auto;
      overflow:hidden;
   }
   
   .owl-carousel .swiper-slide.slide:first-child {
      position:relative;
      width:100%;
      left:0%;
      top:0;
   }
   
   .swiper-slide.slide {
	   background:#fff;
      position:absolute;
      width:100%;
      left:-100%;
      top:0;
   }
   
   .nextCircle {
      position:absolute;
      top:50%;
      transform:translateY(-50%);
      left:90%;
      width:50px;
      height:50px;
      border-radius: 50%;
      opacity:0.5;
      background-color:black;
      z-index:19;	
   }
   
   .next {
      position:absolute;
      top:50%;
      left:50%;
      transform:translate(-50%,-50%);
      color:white;
      z-index:20;
   
   }
   
   .nextCircle:hover{
      opacity:0.7;
      cursor: pointer;
   }
   
   .fa.fa-arrow-right, .fa.fa-arrow-left {
      font-size:30px;
	   font-family:'fontawesome';
	   color:#fff;
   }
   
   .prevCircle {
      position:absolute;
      top:50%;
      transform:translateY(-50%);
      right:90%;
      width:50px;
      height:50px;
      border-radius: 50%;
      opacity:0.5;
      background-color:black;
      z-index:19;	
   }
   
   .previous {
      position:absolute;
      top:50%;
      left:50%;
      transform:translate(-50%,-50%);
      color:white;
      z-index:20;
      
   }
   
   .prevCircle:hover {
      opacity: 0.7;
      cursor: pointer;
   }
	 #testimonials-slider{
	 position:relative;
	 }
	 .nextCircle,.prevCircle{
	 padding:5px;
	 }
	
	 
	
	
	 
	 @media(min-width:767px){
	 .translate-minus{
	 transform:translate(0px,-50px);
	 }
	 }
	 #client-logo.owl-carousel{
	 overflow-y:unset;
	 }
	 
	 </style>
	<style>
    /* CSS for the WhatsApp widget */
    .whatsapp-widget {
      position: fixed;
      bottom: 75px;
		width:150px;
		background-color:#00a884;
		border-radius:5%;
      right: -170px; /* Initially hidden */
      z-index: 9999;
      transition: right 0.3s ease-in-out;
    }
    .whatsapp-widget:hover {
      right: 20px; /* Display on hover */
    }
    .whatsapp-widget img {
      width: 50px;
      height: 50px;
    }
		#hidden-text {
            display: none;
        }
		.list li{
		list-style-type: none;
		}
	</style>
	
</head>

<body>

  <!-- ======= Top Bar ======= -->
  <div id="topbar" class="d-flex align-items-center fixed-top">
    <div class="container d-flex justify-content-between">
      <div class="contact-info d-flex align-items-center">
        <i class="bi bi-envelope"></i> <a href="mailto:contact@example.com">info@precisionpathlab.com</a>
        <i class="bi bi-phone"></i> +91-7230002896 
      </div>
      <div class="d-none d-lg-flex social-links align-items-center">
     
        <a href="https://www.facebook.com/precisonpathlab" class="facebook"><i class="bi bi-facebook"></i></a>
        <a href="https://www.instagram.com/precisionpathlab/" class="instagram"><i class="bi bi-instagram"></i></a>
      </div>
    </div>
  </div>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center">

		<a href="https://precisionpathlab.com/" class="logo me-auto"><img src="assets/img/pathlab.png" alt="Precision Pathlab" class="img-fluid"></a>

		<nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="nav-link scrollto active" href="https://precisionpathlab.com/">Home</a></li>
          <li><a class="nav-link scrollto" href="about.php">About Us</a></li>
          <li><a class="nav-link scrollto" href="book-test.php">Book a Test</a></li>
		  <!--<li class="dropdown"><a href="#"><span>Book a Test</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="health-packages.php">Health Packages</a></li>
            </ul>
          </li>-->
         <li><a class="nav-link scrollto" href="full-body-check-up-in-jaipur.php">Health Packages</a></li>
          <li><a class="nav-link scrollto" href="laboratories.php">Our Laboratories</a></li>
          <li><a class="nav-link scrollto" href="home-collection.php">Home Collection</a></li>
          <li><a class="nav-link scrollto" href="contact.php">Contact</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

      <a href="http://175.111.130.182/precision/design/online_lab/default.aspx" id="onlinereport" target="_blank" class="appointment-btn scrollto"><span class="d-none d-md-inline">Online</span> Report</a>
		
    </div>

  </header><!-- End Header -->

	<!--<section>
		<div id="carouselExampleCaptions" class="carousel slide carousel-dark">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active">
       <img src="../img/hero-image.jpg" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block w-100">
        <p>WELCOME TO PRECISION LAB</p>
        <p class="text-uppercase">Best Pathology Services as per your need.</p>
		  <a href="../about.html" class="appointment-btn text-uppercase m-0">Click TO know More</a>
      </div>
    </div>
    <div class="carousel-item">
      <img src="assets/img/Precision Pathlab banner 4 .png" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
        <p>Second slide label</p>
        <p>Some representative placeholder content for the second slide.</p>
      </div>
    </div>
    <div class="carousel-item">
      <img src="assets/img/Precision Pathlab banner 4 .png" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
        <p>Third slide label</p>
        <p>Some representative placeholder content for the third slide.</p>
      </div>
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
	</section> -->
  <!-- ======= Hero Section ======= --><br><br><br><br>
	<div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
  
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="img/Best Path Lab in Jaipur.webp" class="d-block w-100" alt="Best Path Lab in Jaipur">
		 <div class="carousel-caption d-block bottom-0">
         <a href="../book-test.php" class="appointment-btn text-uppercase">Book Now</a>
      </div>
    </div>
    <div class="carousel-item">
      <img src="img/pathology-labs-in-jaipur.webp" class="d-block w-100" alt="Pathology Lab in Jaipur">
      <div class="carousel-caption d-block bottom-0">
         <a href="../home-collection.php" class="appointment-btn text-uppercase">Book Now</a>
      </div>
    </div>
    <div class="carousel-item">
      <img src="img/Paths-lab-in-Jaipur.webp" class="d-block w-100" alt="Paths Lab">
      <div class="carousel-caption d-block bottom-0">
         <a href="../full-body-check-up-in-jaipur.php" class="appointment-btn text-uppercase">Book Now</a>
      </div>
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div><br><br>
<br><br>

	
	
	
  <!--<section  class="d-flex align-items-center">
    <div class="container">
      <h1>Welcome to Precision Lab</h1>
      <h2>Best Pathology Services as per your need </h2>
      <a href="about.html" class="btn-get-started scrollto">Click to Know more</a>
    </div>
  </section>-->
<!-- End Hero -->

  <main id="main">

    <!-- ======= Why Us Section ======= -->
    <section id="why-us" class="why-us p-0 translate-minus">
      <div class="container">

        <div class="row mt-2">
			<div class="col-12">
				<h1>Best Path Lab in Jaipur - Precision Pathlab</h1>
				<p>Precision Pathlab in Jaipur is renowned for its excellence in diagnostic services. We  ensures exceptional accuracy and reliability in medical testing, making it the preferred choice for healthcare in the Pink City. <span id="hidden-text"> Our priority is to treat every specimen/sample with equal promptness and expert attention. Contact us now to experience Best diagnostic care in Jaipur.</span><a style="color:red; cursor:pointer;" class="pl-1" id="read-more-button">Read More</a></p>
				
				<br>
			
				<a class="btn btn-primary" href="https://precisionpathlab.com/about.html">Learn More</a>
			</div>
			  <div class="section-title">
          <h2>Explore our Main Services</h2>
          <p>We provide wide range of essential pathology services in Jaipur. Our experienced team guarantee top-quality care for all your diagnostic requirements at your home also.</p>
        </div>

        <div class="row mb-4">
       
			<!--<div class="col-lg-3 col-md-6 d-flex align-items-stretch">
            <div class="icon-box">
              <div class="icon"><img src="assets/img/icon1.png" width="50" height="50"></div>
              <h4><a href="">Pathology Testing</a></h4>
              <p>Pathology means the study of disease and its causes and progression. Pathology tests cover blood tests, and tests on urine, stools (faeces) and bodily tissues. </p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch mt-4 mt-md-0">
            <div class="icon-box">
              <div class="icon"><img src="assets/img/icon2.png" width="50" height="50"></div>
             
              <p>Blood chemistry tests are blood tests that measure amounts of certain chemicals in a sample of blood. They show how well certain organs are working and can help find abnormalities. </p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch mt-4 mt-lg-0">
            <div class="icon-box">
              <div class="icon"><img src="assets/img/icon3.png" width="50" height="50"></div>
              
              <p>This test looks at a sample of your urine under a microscope. It can see cells from your urinary tract, blood cells, crystals, bacteria, parasites, and cells from tumors.</p>
            </div>
          </div>
			<div class="col-lg-3 col-md-6 d-flex align-items-stretch mt-4 mt-lg-0">
            <div class="icon-box">
              <div class="icon"><img src="assets/img/icon3.png" width="50" height="50"></div>
             
              <p>This test looks at a sample of your urine under a microscope. It can see cells from your urinary tract, blood cells, crystals, bacteria, parasites, and cells from tumors.</p>
            </div>
          </div>
-->
			<div style="border:1px solid whitesmoke; border-radius:15px; box-shadow:1px 3px 1px 1px lightgrey;" class="col-lg-3 col-md-6 mt-4 p-2">
				<b>COMPLETE BLOOD COUNT (CBC)</b>
				<p class="text-primary">Report Delivery: Same Day</p>
				<div class="row">
					<div class="col-6">
						<p style="font-size:13px;" class="text-success"><i style="color:green;" class="bi bi-patch-check-fill"></i> Home Collection</p>
					</div>
					<div class="col-6">
					   <p style="font-size:13px;" class="text-success"><i style="color:green;" class="bi bi-patch-check-fill"></i> Lab visit</p>
					</div>
				</div>
				<a href="https://precisionpathlab.com/book-test.php">Know More</a>
			</div>
			<div style="border:1px solid whitesmoke; border-radius:15px; box-shadow:1px 3px 1px 1px lightgrey;" class="col-lg-3 col-md-6 mt-4 p-2">
				<b>TSH (Thyroid Stimulating Hormone)</b>
				<p class="text-primary">Report Delivery: Same Day</p>
				<div class="row">
					<div class="col-6">
						<p style="font-size:13px;" class="text-success"><i style="color:green;" class="bi bi-patch-check-fill"></i> Home Collection</p>
					</div>
					<div class="col-6">
					   <p style="font-size:13px;" class="text-success"><i style="color:green;" class="bi bi-patch-check-fill"></i> Lab visit</p>
					</div>
				</div>
				<a href="https://precisionpathlab.com/book-test.php">Know More</a>
			</div>
			<div style="border:1px solid whitesmoke; border-radius:15px; box-shadow:1px 3px 1px 1px lightgrey;" class="col-lg-3 col-md-6 mt-4 p-2">
				<b>ALLERGY TEST</b>
				<p class="text-primary">Report Delivery: Same Day</p>
				<div class="row">
					<div class="col-6">
						<p style="font-size:13px;" class="text-success"><i style="color:green;" class="bi bi-patch-check-fill"></i> Home Collection</p>
					</div>
					<div class="col-6">
					   <p style="font-size:13px;" class="text-success"><i style="color:green;" class="bi bi-patch-check-fill"></i> Lab visit</p>
					</div>
				</div>
				<a href="https://precisionpathlab.com/book-test.php">Know More</a>
			</div>
			<div style="border:1px solid whitesmoke; border-radius:15px; box-shadow:1px 3px 1px 1px lightgrey;" class="col-lg-3 col-md-6 mt-4 p-2">
				<b>SWINE FLU TEST</b>
				<p class="text-primary">Report Delivery: Same Day</p>
				<div class="row">
					<div class="col-6">
						<p style="font-size:13px;" class="text-success"><i style="color:green;" class="bi bi-patch-check-fill"></i> Home Collection</p>
					</div>
					<div class="col-6">
					   <p style="font-size:13px;" class="text-success"><i style="color:green;" class="bi bi-patch-check-fill"></i> Lab visit</p>
					</div>
				</div>
				<a href="https://precisionpathlab.com/book-test.php">Know More</a>
			</div>

        </div>
		  <div class="row justify-content-center mb-4">
			  <div class="col-4">
				  <a href="https://precisionpathlab.com/book-test.php" class="btn btn-primary w-100">More Test</a>
			  </div>
		</div>
			
			
		
         <!--	 <div class="col-lg-4 d-flex align-items-stretch mt-4">
            <div class="content">
             
              <p>
                Established in the year 2012, Precision Path Lab in Mansarovar,Jaipur listed under Laboratory Testing Services in Jaipur.<br>
                Precision Path Lab provides the following services: Diagnostics & Blood Test, Pathology Labs, X Ray, ECG, Utrasound Graphy Etc.
              </p>
              <div class="text-center">
                <a href="/laboratories.html" class="more-btn">Learn More <i class="bx bx-chevron-right"></i></a>
              </div>
            </div>
          </div>
          <div class="col-lg-8 d-flex align-items-stretch">
            <div class="icon-boxes d-flex flex-column justify-content-center">
              <div class="row">
                <div class="col-xl-4 d-flex align-items-stretch">
                  <div class="icon-box mt-4 mt-xl-0 text-start">
                    <img src="assets/img/chemistry.png" width="80" height="100" style="padding-bottom: 20px;">

                   
                    <p>We have professional laboratory diagnostic services for patients in our care. We wish to meet the current requirement of clinicians to diagnose 
and manage their patients by providing precise and accurate reports.</p>
                  </div>
                </div>
                <div class="col-xl-4 d-flex align-items-stretch">
                  <div class="icon-box mt-4 mt-xl-0 text-start">
                    <img src="assets/img/microscope.png" width="80" height="100" style="padding-bottom: 20px;">
                 
                    <p>Analytical Techniques are the methods used for the qualitative and quantitative determination of concentration of a compound by using various 
techniques like titrations, spectroscopies, chromatography, and gravimetric analysis.</p>
                  </div>
                </div>
                <div class="col-xl-4 d-flex align-items-stretch">
                  <div class="icon-box mt-4 mt-xl-0 text-start">
                    <img src="assets/img/plab.png" width="80" height="100" style="padding-bottom: 20px;">
                   
                    <p>Improves facilitation of accurate and rapid diagnostics, efficiency of treatment and reduction of errors in the laboratory process. Precision Path lab is the best pathology lab in jaipur </p>
                  </div>
                </div>
              </div>
            </div>
          </div> -->
			<div class="row" style="background-color:#f1f7fd;">
				<div class="col-12">
				
			<div class="row mt-4" >
				<div class="col-12">
					<h2 class="text-center">Why Choose Precision Pathlab as your Pathology Lab in Jaipur?</h2>
				</div>
			</div>
			<div class="row mt-4" >
				<div class="col-lg-6">
					<ul class="list">
						<li><i style="color:green;" class="bi bi-patch-check-fill"></i> Accurate and Reliable Results</li>
						<li><i style="color:green;" class="bi bi-patch-check-fill"></i> Comprehensive Test Menu</li>
						<li><i style="color:green;" class="bi bi-patch-check-fill"></i> Cutting-Edge Technology</li>
						<li><i style="color:green;" class="bi bi-patch-check-fill"></i> Experienced and Certified Staff</li>
						<li><i style="color:green;" class="bi bi-patch-check-fill"></i> Strict Quality Control</li>
						<li><i style="color:green;" class="bi bi-patch-check-fill"></i> Convenient Locations</li>
					</ul>
					
				</div>
				<div class="col-lg-6">
					<ul class="list">
						<li><i style="color:green;" class="bi bi-patch-check-fill"></i> Timely Results</li>
						<li><i style="color:green;" class="bi bi-patch-check-fill"></i> Online Access</li>
						<li><i style="color:green;" class="bi bi-patch-check-fill"></i> Excellent Customer Service</li>
						<li><i style="color:green;" class="bi bi-patch-check-fill"></i> Affordable Pricing</li>
						<li><i style="color:green;" class="bi bi-patch-check-fill"></i> Patient Privacy and Confidentiality</li>
						<li><i style="color:green;" class="bi bi-patch-check-fill"></i> Community Engagement</li>
					</ul>
					
				</div>
				<div class="row justify-content-evenly">
					<div class="col-lg-5 mb-4" style="border-radius:15px; background-color:#f3f3f4; box-shadow:2px 2px 1px grey;">
						<div class="row" >
						<div class="col-12 p-3">
							
							<a href="https://www.google.com/search?q=Precision+Path+Lab+%7C+Best+Diagnostic+Centre+%7C+Full+body+Checkup+in+Mansarovar%2C+Jaipur&rlz=1C1VDKB_enIN1070IN1070&oq=Precision+Path+Lab+%7C+Best+Diagnostic+Centre+%7C+Full+body+Checkup+in+Mansarovar%2C+Jaipur&aqs=chrome..69i57j46i175i199i512.353j0j9&sourceid=chrome&ie=UTF-8">Precision Path Lab | Best Diagnostic Centre | Full body Checkup in Mansarovar, Jaipur</a><br><br>
							<b>Rated 4.3/5 Based on 260 + Reviews</b><br>
							<i style="color:orange;" class="bi bi-star-fill"></i><i style="color:orange;" class="bi bi-star-fill"></i><i style="color:orange;" class="bi bi-star-fill"></i><i style="color:orange;" class="bi bi-star-fill"></i><i style="color:orange;" class="bi bi-star-half"></i>
							
						</div>
					</div>
					</div>
					<div class="col-lg-5 mb-4" style="border-radius:15px; background-color:#f3f3f4; box-shadow:2px 2px 1px grey;">
						<div class="row">
						<div class="col-12 p-3">
							
							<a href="https://www.google.com/search?q=Precision+Path+Lab+%7C+Best+Diagnostic+Centre+%7C+Full+body+Checkup+in+Vaishali+Nagar%2C+Jaipur&rlz=1C1VDKB_enIN1070IN1070&oq=Precision+Path+Lab+%7C+Best+Diagnostic+Centre+%7C+Full+body+Checkup+in+Vaishali+Nagar%2C+Jaipur&aqs=chrome.0.69i59.397j0j9&sourceid=chrome&ie=UTF-8">Precision Path Lab | Best Diagnostic Centre | Full body Checkup in Vaishali Nagar, Jaipur</a><br><br>
							<b >Rated 5/5 Based on 50 + Reviews</b><br>
							<i style="color:orange;" class="bi bi-star-fill"></i><i style="color:orange;" class="bi bi-star-fill"></i><i style="color:orange;" class="bi bi-star-fill"></i><i style="color:orange;" class="bi bi-star-fill"></i><i style="color:orange;" class="bi bi-star-fill"></i>
							
						</div>
					</div>
					</div>
				</div>
				 <div class="row justify-content-center mb-4">
			  <div class="col-4">
				  <a href="https://precisionpathlab.com/book-test.php" class="btn btn-primary w-100">Book Test</a>
			  </div>
		</div>
			</div>
			</div>
		  </div>
			
			
			
        </div>

      </div>
    </section><!-- End Why Us Section -->

    <!-- ======= About Section ======= -->
    <!--<section id="about" class="about">
      <div class="container-fluid">

        <div class="row">
          <div class="col-xl-5 col-lg-6 d-flex justify-content-center align-items-stretch position-relative">
            <img class="img-fluid" src="assets/img/pathlab.webp" width="500" height="500"> 
          </div>

          <div class="col-xl-7 col-lg-6 icon-boxes d-flex flex-column align-items-stretch justify-content-center py-5 px-lg-5">
         
            <p>At Precision Path Lab, our priority is to treat every specimen/sample with equal promptness and expert attention. <br>
				Needless to say, in critical cases we will provide special and quick service. Precision path lab Serving for 7+ years.</p>

            <div class="icon-box">
              <div class="icon"><i class="bx bx-fingerprint"></i></div>
              <p class="title"><a href="">All the services you expect from a clinical trial lab</a></p>
				<p>  
					<br><br><b> &bull; Sample Preparation <br> &bull; Healthcare Labs</b><br>
				  <b>&bull; Advanced Microscopic <br> &bull; Environmental Testing</b><br>
				  <b> &bull; Anatomical Pathology <br> &bull; Pathology Testing</b>
				</p>
            </div>
            

          </div>
        </div>

      </div>
    </section>--><!-- End About Section -->
	 <script type="application/ld+json">
  {
    "@context"      : "https://schema.org",
    "@type"         : "Review",
    "itemReviewed"  : {
        "@type"     : "LocalBusiness",
        "address"   : {
            "@type"             : "PostalAddress",
            "addressLocality"   : "Jaipur"
        },
        "name"          :   "Pathology Lab in Jaipur",
        "description"   : "Precision Path Lab: Trusted pathology labs in Jaipur. Accurate diagnostics, personalized care. Visit us for reliable results.",
        "URL"           : "https://precisionpathlab.com/",
        "Image"         : "hhttps://www.precisionpathlab.com/assets/img/pathlab.png",
        "priceRange"    : "Tests @ ₹80",
        "telephone"     : "+917230002896"
    },
    "author": {
        "@type" : "Organization",
        "name"  : "Precision Path Lab",
        "URL"   : "https://www.precisionpathlab.com/"
    },
    "ReviewRating"      : {
        "@type"         : "AggregateRating",
        "bestRating"    : "5",
        "ratingCount"   : 115012,
        "ratingValue"   : 4.5,
        "itemReviewed"  : {
            "@type"     : "Thing",
            "name"      : "ServiceReview"
        }
    }
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org/", 
  "@type": "BreadcrumbList", 
  "itemListElement": [{
    "@type": "ListItem", 
    "position": 1, 
    "name": "Pathology Lab in Jaipur",
    "item": "https://precisionpathlab.com/"  
  },{
    "@type": "ListItem", 
    "position": 2, 
    "name": "Book Test",
    "item": "https://precisionpathlab.com/book-test.php"  
  },{
    "@type": "ListItem", 
    "position": 3, 
    "name": "Health Packages",
    "item": "https://precisionpathlab.com/full-body-check-up-in-jaipur.php"  
  },{
    "@type": "ListItem", 
    "position": 4, 
    "name": "Home Collection",
    "item": "https://precisionpathlab.com/home-collection.php"  
  },{
    "@type": "ListItem", 
    "position": 5, 
    "name": "Our Laboratories",
    "item": "https://precisionpathlab.com/laboratories.php"  
  },{
    "@type": "ListItem", 
    "position": 6, 
    "name": "Contact Us",
    "item": "https://precisionpathlab.com/contact.php"  
  }]
}
</script>
	    <script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  "name": "Precision Path Lab | Best Diagnostic Centre | Full body Checkup in Mansarovar, Jaipur",
  "image": "https://lh3.googleusercontent.com/p/AF1QipMk2G0tcTwwH2Jdo4uk56jHssJ5C30JTMSM0dI=s1360-w1360-h1020",
  "@id": "https://goo.gl/maps/LVAiFH9bNcTAP8sj6",
  "url": "https://goo.gl/maps/LVAiFH9bNcTAP8sj6",
  "telephone": "07230002896",
  "priceRange": "80-1000",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "72/2, Shipra Path, Patel Marg, Mansarovar, Jaipur, Rajasthan 302020",
    "addressLocality": "Jaipur",
    "postalCode": "302020",
    "addressCountry": "IN"
  },
  "geo": {
    "@type": "GeoCoordinates",
    "latitude": 26.8547295,
    "longitude": 75.7730619
  },
  "openingHoursSpecification": [{
    "@type": "OpeningHoursSpecification",
    "dayOfWeek": [
      "Monday",
      "Tuesday",
      "Wednesday",
      "Thursday",
      "Friday",
      "Saturday"
    ],
    "opens": "08:00",
    "closes": "21:00"
  },{
    "@type": "OpeningHoursSpecification",
    "dayOfWeek": "Sunday",
    "opens": "08:00",
    "closes": "15:00"
  }] 
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  "name": "Precision Path Lab | Best Diagnostic Centre | Full body Checkup in Vaishali Nagar, Jaipur",
  "image": "https://lh3.googleusercontent.com/p/AF1QipMqdwuuXWpjUSjtBInOty7UrH2Twj9aOG1sNzrb=s1360-w1360-h1020",
  "@id": "https://goo.gl/maps/jETv6YBuDZGZ5PbS7",
  "url": "https://goo.gl/maps/jETv6YBuDZGZ5PbS7",
  "telephone": "08696222006",
  "priceRange": "80-1000",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "2nd Floor, 9, Infront Of, Akshardham Temple, 102, Akruti Apartments, Chitrakoot, Jaipur, Rajasthan 302021",
    "addressLocality": "Jaipur",
    "postalCode": "302021",
    "addressCountry": "IN"
  },
  "geo": {
    "@type": "GeoCoordinates",
    "latitude": 26.9022189,
    "longitude": 75.7406225
  },
  "openingHoursSpecification": [{
    "@type": "OpeningHoursSpecification",
    "dayOfWeek": [
      "Monday",
      "Tuesday",
      "Wednesday",
      "Thursday",
      "Friday",
      "Saturday"
    ],
    "opens": "08:00",
    "closes": "21:00"
  },{
    "@type": "OpeningHoursSpecification",
    "dayOfWeek": "Sunday",
    "opens": "08:00",
    "closes": "15:00"
  }],
  "sameAs": [
    "https://www.facebook.com/precisonpathlab",
    "https://www.instagram.com/precisionpathlab/"
  ] 
}
</script>
	    <!-- test review -->
	  <section  id="testimonials-slider" class="testimonials">
	   <div class="container-fluid text-center speciality w-100 p-0">
		   <div class="section-title">
			  <p style="font-size:32px; font-weight:bold;" class="text-primary">What Our Patients Say About Us</p>
			  <p>Here's what our valued patients have to say about their experiences with our Pathology services </p>
			</div>
    <div class="row">
   <div id="client-logo" class="owl-carousel owl-theme" style="opacity: 1; display: block;">
      <div class="owl-wrapper-outer">
                      
		              <div class="swiper-slide slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item text-start">
                  <img src="img/ram chand.webp" class="testimonial-img" alt="testimonial ram chand">
                  <p>Yogesh Saini </p>
                  <p>Jaipur</p>
                  <p>
                    <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                   This lab is the best lab in Jaipur. highly skilled and technical staff where one can actually get all query related to sample collection be resolved and center provide timely and quality services which is actually need of healthcare industry.
                    <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                  </p>
                </div>
              </div>
            </div> 
		  <div class="swiper-slide slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item text-start">
                  <img src="assets/img/testimonials/kartik.jpeg" class="testimonial-img" alt="testimonial Kartik">
                  <p>Jagat Singh</p>
                  <p>Jaipur</p>
                  <p>
                    <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                   I was looking for a reliable lab for my complete blood test CBC in Jaipur, And I came across precision path lab on google and contacted them. Overall nice staff support, clean environment, prices were bearable and they delivered my reports on time. Recommended path lab👍🏻👍🏻

                    <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                  </p>
                </div>
              </div>
            </div>  
		  <div class="swiper-slide slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item text-start">
                  <img src="img/kartik.webp" class="testimonial-img" alt="testimonial kartik Jaipur">
                  <p>Kartik Shanwani</p>
                  <p>Jaipur</p>
                  <p>
                    <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                   	I recently had to get some lab work done and found this pathlab in Jaipur. The staff was incredibly friendly and made the process very easy. The facility was clean and well-maintained, and I was in and out in no time. Highly recommend it.
                    <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                  </p>
                </div>
              </div>
		  </div>
		  <div class="swiper-slide slide">
		  <div class="testimonial-wrap">
                <div class="testimonial-item text-start">
                  <img src="img/abhishek.webp" class="testimonial-img" alt="testimonial Abhishek">
                  <p>Abhishek Sharma</p>
                  <p>Jaipur</p>
                  <p>
                    <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                   My experience was very good and I did full body check. The staff is very good and I got the reports on right time. This is a good lab for Pathology services in Jaipur, Thank you..

                    <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                  </p>
                </div>
              </div>
		  </div>
		   <div class="swiper-slide slide">
		  <div class="testimonial-wrap">
                <div class="testimonial-item text-start">
                  <img src="img/testimonials/reema dev.webp" class="testimonial-img" alt="testimonial Reema Dev">
                  <p>Swati Meena</p>
                  <p>Jaipur</p>
                  <p>
                    <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  My mother was recently diagnosed with a serious illness, and we were referred to Precision Path Lab for her blood tests. I was very impressed with the professionalism and compassion of the staff at Precision Path Lab. This is the best pathlab in Jaipur.

                    <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                  </p>
                </div>
              </div>
		  </div>
            
      </div>
   </div>
</div>
</div>
		       <div class="nextCircle">
      <!--<i class="fa fa-light fa-arrow-right next" ></i>-->
				   <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="#fff" class="bi bi-caret-right-fill" viewBox="0 0 16 16">
  <path d="m12.14 8.753-5.482 4.796c-.646.566-1.658.106-1.658-.753V3.204a1 1 0 0 1 1.659-.753l5.48 4.796a1 1 0 0 1 0 1.506z"/>
</svg>
   </div>
   <div class="prevCircle">
      <!--<i class="fa fa-arrow-left previous" ></i>-->
	   <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="#fff" class="bi bi-caret-left-fill" viewBox="0 0 16 16">
  <path d="m3.86 8.753 5.482 4.796c.646.566 1.658.106 1.658-.753V3.204a1 1 0 0 0-1.659-.753l-5.48 4.796a1 1 0 0 0 0 1.506z"/>
</svg>
   </div>
	  </section>
	  <!-- test review -->

    <!-- ======= Counts Section ======= -->
    <section id="counts" class="counts">
      <div class="container">

        <div class="row">
				<div class="section-title">
				  <h2>About Precision Path Lab</h2>
				  <p class="text-start">Welcome to Precision Path Lab, Jaipur's leading laboratory for exceptional pathology services. Our expert team of four doctors and 15 clinical staff members, backed by over 15 years of experience, ensures accurate and prompt results. We provide services in 2 renowned location of Jaipur city, In mansarover and In Vaishali Nagar. Our services include diagnostics, blood tests, pathology labs, X-rays, ECGs, ultrasound, etc.
</p><br>
			</div>
         

        </div>
		   <div class="row justify-content-center mb-4">
			  <div class="col-4">
				  <a href="tel:+918696222281" class="btn btn-primary w-100">Call us now</a>
			  </div>
		</div>
		  

      </div><br><br>
		 <hr style="width:60%; color:grey;">
    </section><!-- End Counts Section -->

    <!-- ======= Departments Section ======= -->
    <section id="departments" class="departments section-bg">
      <div class="container">
        <div class="section-title">
          <h3 style="font-weight:bold; margin-top:-60px;">Our Departments</h3>
          <p>We offer Advance Imaging Technology & Pathology services and Follow highest quality standards. Our center is equipped with the Hi-tech instruments providing best in class diagnostic and imaging services. 
</p>
        </div>

        <div class="row gy-4">
          <div class="col-lg-3">
            <ul class="nav nav-tabs flex-column">
              <li class="nav-item">
                <a class="nav-link active show" data-bs-toggle="tab" href="#tab-1">PATHOLOGY</a>
              </li>
              
              <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#tab-3">CARDIOLOGY</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#tab-4">NEUROLOGY</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#tab-5">ULTRASONIC</a>
              </li>
            </ul>
          </div>
          <div class="col-lg-9">
            <div class="tab-content">
              <div class="tab-pane active show" id="tab-1">
                <div class="row gy-4">
                  <div class="col-lg-8 details order-2 order-lg-1">
                    <p>Pathology</p>
                    <p>Our pathology department is at the heart of Precision Path Lab, where we conduct a wide range of tests and examinations to help diagnose and monitor various medical conditions. Our team of experienced pathologists and laboratory technicians utilize cutting-edge technology and methodologies to analyze blood, tissue, and other bodily fluids, ensuring accurate and timely results. Whether it's routine blood tests or complex genetic analyses, you can trust us for precise diagnostics.
</p>
                  </div>
                  <div class="col-lg-4 text-center order-1 order-lg-2">
                    <img src="assets/img/dept-pathology.jpg" alt="dept-pathology" class="img-fluid">
                  </div>
                </div>
              </div>
          
              <div class="tab-pane" id="tab-3">
                <div class="row gy-4">
                  <div class="col-lg-8 details order-2 order-lg-1">
                    <p>Cardiology</p>
                    <p>The cardiology department at Precision Path Lab focuses on the assessment and management of heart health. We offer a comprehensive range of cardiological services, including EKGs, echocardiograms, stress tests, and more. Our board-certified cardiologists work diligently to detect heart conditions, provide accurate diagnoses, and develop personalized treatment plans to promote heart wellness.
</p>
                  </div>
                  <div class="col-lg-4 text-center order-1 order-lg-2">
                    <img src="assets/img/dept-cardiology.jpg" alt="Cardiology" class="img-fluid">
                  </div>
                </div>
              </div>
              <div class="tab-pane" id="tab-4">
                <div class="row gy-4">
                  <div class="col-lg-8 details order-2 order-lg-1">
                    <p>Neurology</p>
                    <p>At Precision Path Lab, our neurology department is dedicated to addressing neurological concerns and disorders. Our neurologists employ advanced diagnostic techniques, such as EEGs, EMGs, and brain imaging, to assess and diagnose conditions affecting the nervous system. Whether you're dealing with headaches, seizures, or neurological disorders, our specialists are here to provide expert care and guide you towards appropriate treatment options.</p>
                  </div>
                  <div class="col-lg-4 text-center order-1 order-lg-2">
                    <img src="assets/img/dept-neurology.jpg" alt="Neurology" class="img-fluid">
                  </div>
                </div>
              </div>
              <div class="tab-pane" id="tab-5">
                <div class="row gy-4">
                  <div class="col-lg-8 details order-2 order-lg-1">
                    <p>Ultrasonic</p>
                    <p>In our ultrasonic department, we harness the power of ultrasound technology to visualize internal structures and organs within the body. Our skilled sonographers and radiologists perform ultrasound scans that aid in diagnosing conditions across multiple specialties, including obstetrics, gynecology, cardiology, and abdominal imaging. We prioritize patient comfort and safety, making the experience as non-invasive and informative as possible.
</p>
                  </div>
                  <div class="col-lg-4 text-center order-1 order-lg-2">
                    <img src="img/Path lab in Jaipur.webp" alt="Ultrasonic" class="img-fluid">
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section><!-- End Departments Section -->

	  
	



    <!-- ======= Testimonials Section ======= -->
    <!-- <section id="testimonials" class="testimonials">
      <div class="container">
			<div class="section-title">
			 
			  <p> Customer's feedback regarding our services...  </p>
			</div>
        <div class="testimonials-slider swiper" data-aos="fade-up" data-aos-delay="100">
          <div class="swiper-wrapper">

            <div class="swiper-slide">
              <div class="testimonial-wrap">
               <div class="testimonial-item">
                  <img src="assets/img/testimonials/testimonials-1.jpg" class="testimonial-img" alt="">
                  
                 
                  <p>
                    <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                    The arrangement is good and due precautions have been taken. Connected with this lab from last 5 years or so. Always trusted with their results. Truly professional. 
                    <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                  </p>
                </div>
				  <div class="testimonial-item">
                  <img src="assets/img/testimonials/kartik.jpeg" class="testimonial-img" alt="">
                
                
                  <p>
                    <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                   	I recently had to get some lab work done and found this pathlab in Jaipur. The staff was incredibly friendly and made the process very easy. The facility was clean and well-maintained, and I was in and out in no time. Highly recommend!  
                    <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                  </p>
                </div>
				   <div class="testimonial-item">
                  <img src="assets/img/testimonials/reema dev.jpg" class="testimonial-img" alt="">
                  
              
                  <p>
                    <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                   	Visited this place to get my RT-PCR test for travel purpose. Although i don't wish anyone to go through such tests yet I had good experience there and results were out within 24 hours. Would highly recommend this place for travellers for testing. 
                    <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                  </p>
                </div>
				   <div class="testimonial-item">
                  <img src="assets/img/testimonials/ram chand.jpg" class="testimonial-img" alt="">
                 
                 
                  <p>
                    <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                   Good quality of reports and nice staff, Dr sameer is a very much trained in hemat and dr arundhati has great polite attitude  
                    <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                  </p>
                </div>
              </div>
            </div>

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <img src="assets/img/testimonials/testimonials-2.jpg" class="testimonial-img" alt="">
                  
                  
                  <p>
                    <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                    Very friendly and helpful. Turn around time exceeded expectations. Stayed in contact before and after analysis. The report was just what we wanted.
                    <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                  </p>
                </div>
              </div>
            </div>

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <img src="assets/img/testimonials/testimonials-3.jpg" class="testimonial-img" alt="">
                
                
                  <p>
                    <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                    Precision path labs is very nice. Its gives up better service and their report is to liable and trustable. Almost report is accurate and reports gives minimum time according to others labs. Every test are available here just like vitamin d, thyride, spootam, Seamen test.
                    <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                  </p>
                </div>
              </div>
            </div>

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <img src="assets/img/testimonials/testimonials-4.jpg" class="testimonial-img" alt="">
                  
               
                  <p>
                    <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                    Hello guys its Anand and today I will share my review and opinion about the Precision Pathlabs which is a laboratory in Jaipur. I have gone there for my blood test and I thought that it will take around 1/2 hrs to test the blood but it tales only 10 minutes to complete the blood test so very fast service and without carelessness.
                    <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                  </p>
                </div>
              </div>
            </div>

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <img src="assets/img/testimonials/testimonials-5.jpg" class="testimonial-img" alt="">
                  
               
                  <p>
                    <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                    Very good clinic or good staff people. Always provide the best lab for any type of test with great discount. Will surely recommend everyone to consult Precision lab for every type of tests.
                    <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                  </p>
                </div>
              </div>
            </div>

          </div>
          <div class="swiper-pagination"></div>
        </div>

      </div>
    </section> -->
	  <!-- End Testimonials Section -->
	  
	
	  
    <!-- ======= Appointment Section ======= -->
	  <section id="appointment" class="appointment section-bg">
      <div class="container-fluid">

        <div class="row">
          <div class="col-xl-5 col-lg-6 d-flex justify-content-center align-items-stretch position-relative">
            <img src="img/pathology lab in jaipur.webp" alt="precision pathology lab in jaipur" width=100% height="100%"> 
          </div>

          <div class="col-xl-7 col-lg-6 icon-boxes d-flex flex-column align-items-stretch justify-content-center py-5 px-lg-5">
          <div class="section-title">
			  <p style="font-size:26px; font-weight:bold;">Make an appointment</p>
			</div>
			  			  
		 <form method="post" id="make-an-appointment">
          <div class="row">
            <div class="col-md-6 form-group">
              <input type="text" name="name" class="form-control txtNumeric1" id="name" placeholder="Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars" required>
              <div class="validate"></div>
            </div>
            <div class="col-md-6 form-group mt-3 mt-md-0">
              <input type="email" class="form-control" name="email" id="email" placeholder="Email Id" data-rule="email" data-msg="Please enter a valid email" required>
              <div class="validate"></div>
            </div>
			   </div>
			  <div class="row mt-2">
            <div class="col-md-6 form-group mt-3 mt-md-0">
              <input type="text" class="form-control numbersOnly" maxlength="10" minlength="10" name="phone" id="phone" placeholder="Phone Number"  required>
              <div class="validate"></div>
            </div>
			   <div class="col-md-6 form-group mt-3 mt-md-0">
              <select name="department" id="department" class="form-select" required>
                <option value="">Select Department</option>
                <option value="Pathology">Pathology </option>
                <option value="Cardiology">Cardiology </option>
                <option value="Neurology">Neurology </option>
                <option value="Ultrasonic">Ultrasonic </option>
                <option value="Clinical test">Clinical test </option>
				  
              </select>
              <div class="validate"></div>
            </div>
			 </div>

          <div class="form-group mt-3">
            <textarea class="form-control" name="message" rows="5" placeholder="Message (Optional)"></textarea>
            <div class="validate"></div>
          </div>
          <div class="mb-3 text-center">
            <b style="color:green;"></b>
			  
          </div>
          <div class="text-center"><button type="submit" name="submit2" id="make-an-appointment-btn" class="btn btn-primary">Make an Appointment</button></div>
        </form>
            

          </div>
        </div>

      </div>
    </section>
    <!-- End Appointment Section -->
	  <script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [{
    "@type": "Question",
    "name": "How do I book test at my Home?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "We provide the best services at your doorstep, just call us on this number +91-8696222281, +91-141-2786337 or contact us now by filling this form Contact Now!"
    }
  },{
    "@type": "Question",
    "name": "How long does it typically take to receive my test results?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Same Day you’ll get the you report. You’ll receive message on your registered number or receive report on whatsapp."
    }
  },{
    "@type": "Question",
    "name": "Can I get my test results online or through Whatsapp?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Yes, we provide reports on you registered number or on direct on whatsapp. So it is easy for you to check your health at your home."
    }
  },{
    "@type": "Question",
    "name": "How do I choose a right pathology lab?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "While choosing a pathlab, first check that the required test you need is available at that pathlab or not. Look for a lab that has a good reputation and is accredited. It's also important to consider the cost and make sure it fits your budget."
    }
  },{
    "@type": "Question",
    "name": "My personnel information are safe in precision path lab?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Yes, at precision path lab we take care of data of our customers, don’t hesitate to connect with us."
    }
  },{
    "@type": "Question",
    "name": "What precautions are being taken to ensure the safety and hygiene of the Path Lab, especially in light of the COVID-19 pandemic?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "At precision pathlab, we have implemented strict COVID-19 safety measures, including regular sanitization, social distancing, PPE for staff, temperature checks, mandatory masks, and online services. Your safety is our priority."
    }
  },{
    "@type": "Question",
    "name": "What tests are done in pathology?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "All types of tests such as blood test, urine test, genetic tests and many more. These tests helps to diagnose the medical condition of a person"
    }
  },{
    "@type": "Question",
    "name": "Which lab is best for test?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Precision path lab is most famous pathology lab in Jaipur for your tests."
    }
  },{
    "@type": "Question",
    "name": "What is the most common lab test?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Common lab tests include complete blood count - A complete blood count (CBC) is a blood test that measures the number and types of blood cells in your body, including red blood cells, white blood cells, and platelets. It helps diagnose various medical conditions and assess overall health."
    }
  }]
}
</script>
<div class="container">
	<div class="row mt-4">
		<div class="col-12 text-center mb-4">
			<h3>Instagram Wall: Updates You Can't Miss</h3>
		</div>
		<div class="col-12">
			<script src="https://static.elfsight.com/platform/platform.js" async></script>
			<div class="elfsight-app-06f73ce9-42e9-485d-92ff-24db95a9551b" data-elfsight-app-lazy></div>
		</div>
	</div>
	<style>
	
	a[href="https://elfsight.com/instagram-feed-instashow/?utm_source=websites&utm_medium=clients&utm_content=instashow&utm_term=precisionpathlab.com&utm_campaign=free-widget"] {
    opacity: 0!important;
}

</style>




	  <!-- FAq Section -->
	  <div class="container">
	  <div class="row mt-3">
						<div class="col-12">
							<p class="text-center"><b>FAQ's For Best Path Lab in Jaipur</b></p>
							<div class="accordion" id="accordionExample">
  <div class="accordion-item">
    <p class="accordion-header">
      <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
       Q1. How do I book test at my Home? 
      </button>
    </p>
    <div id="collapseOne" class="accordion-collapse collapse show" data-bs-parent="#accordionExample">
      <div class="accordion-body">
        <strong>We provide best services at your door steps, just call us on this number +91-8696222281, +91-141-2786337 or contact us now by filling this form Contact Now!</strong>
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <p class="accordion-header">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
        Q2.How long does it typically take to receive my test results?
 
      </button>
    </p>
    <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
      <div class="accordion-body">
        <strong>Same Day you’ll get the you report. You’ll receive message on your registered number or receive report on whatsapp.</strong>

      </div>
    </div>
  </div>
  <div class="accordion-item">
    <p class="accordion-header">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
       Q3.  Can I get my test results online or through Whatsapp? 
      </button>
    </p>
    <div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
      <div class="accordion-body">
        <strong>Yes, we provide reports on you registered number or on direct on whatsapp. So it is easy for you to check your health at your home.</strong>
      </div>
    </div>
  </div>
	   <div class="accordion-item">
    <p class="accordion-header">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
        Q4.	How do I choose a right pathology lab?

      </button>
    </p>
    <div id="collapseFour" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
      <div class="accordion-body">
        <strong>While choosing a pathlab, first check that the required test you need is available at that pathlab or not. Look for a lab that has a good reputation and is accredited. It's also important to consider the cost and make sure it fits your budget.</strong>
      </div>
    </div>
  </div>
		    <div class="accordion-item">
    <p class="accordion-header">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
        Q5.	My personnel information are safe in precision path lab?
 
      </button>
    </p>
    <div id="collapseFive" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
      <div class="accordion-body">
        <strong>Yes, at precision path lab we take care of data of our customers, don’t hesitate to connect with us.</strong>

      </div>
    </div>
  </div>
				 <div class="accordion-item">
    <p class="accordion-header">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
         Q6.  What precautions are being taken to ensure the safety and hygiene of the Path Lab, especially in light of the COVID-19 pandemic?

      </button>
    </p>
    <div id="collapseSix" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
      <div class="accordion-body">
        <strong>At precision pathlab, we have implemented strict COVID-19 safety measures, including regular sanitization, social distancing, PPE for staff, temperature checks, mandatory masks, and online services. Your safety is our priority.</strong>

      </div>
    </div>
  </div>
				 <div class="accordion-item">
    <p class="accordion-header">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">
         Q7.  What tests are done in pathology?


      </button>
    </p>
    <div id="collapseSeven" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
      <div class="accordion-body">
        <strong>All types of tests such as blood test, urine test, genetic tests and many more. These tests helps to diagnose the medical condition of a person</strong>

      </div>
    </div>
  </div>
 <div class="accordion-item">
    <p class="accordion-header">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseEight" aria-expanded="false" aria-controls="collapseEight">
         Q8.  Which lab is best for test?


      </button>
    </p>
    <div id="collapseEight" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
      <div class="accordion-body">
        <strong>Precision path lab is most famous pathology lab in Jaipur for your tests.</strong>

      </div>
    </div>
  </div>	
				<div class="accordion-item">
    <p class="accordion-header">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseNine" aria-expanded="false" aria-controls="collapseNine">
         Q8.  What is the most common lab test?



      </button>
    </p>
    <div id="collapseNine" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
      <div class="accordion-body">
        <strong>Common lab tests include complete blood count - A complete blood count (CBC) is a blood test that measures the number and types of blood cells in your body, including red blood cells, white blood cells, and platelets. It helps diagnose various medical conditions and assess overall health.</strong>

      </div>
    </div>
  </div>	


					  
</div>
						</div>
					</div>
	  </div>
	  <!-- -->
	  
  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
 <footer id="footer">

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-contact">
            <p>PRECISION HOUSE</p>
            <p>
			  <i class="bi bi-geo-alt"></i> :
			  72/2, Shipra Path, Mansarovar<br>
 			  Jaipur 302020 (India)<br><br>
              <i class="bi bi-phone"></i> : +91 8696222281, 8696222678<br>
              <i class="bi bi-envelope"></i> : info@precisionpathlab.com<br>
            </p><br>

			  <p>Our Timing</p>
			  <p><b>Monday to Saturday </b><br>
 					8:00 AM to 8:30 PM<br>
				 <b>Sunday</b><br>
					8:00 AM to 2:30 PM</p>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
            <p>Quick Links</p>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="https://precisionpathlab.com/">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="about.php">About us</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="full-body-check-up-in-jaipur.php">Health Packages</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="laboratories.php">Our Laboratories</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Home Collection</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="https://precisionpathlab.com/blog/">Our Blog</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="contact.php">Contact Us</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <p>Our Services</p>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Pathology Testing</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Microscopic Testing</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">X-Ray</a></li>
			 <li><i class="bx bx-chevron-right"></i> <a href="https://precisionpathlab.com/feedback.php">Feedback</a></li>
            </ul>
          </div>

          <div class="col-lg-4 col-md-6 footer-newsletter">
            <p class="text-center">Reach Us</p>
			  <div class="row">
				  <div class="col-6">
					  <b>Mansarovar</b><br>
			  <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14238.140506209242!2d75.7730997!3d26.8547344!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396db5230f2899a5%3A0xde62d7d0e085d8c3!2sPrecision%20Path%20Lab%20%7C%20Path%20Lab%20in%20Jaipur%20%7C%20Mansarovar!5e0!3m2!1sen!2sin!4v1680676109737!5m2!1sen!2sin" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
           </div>
				   <div class="col-6">
					   <b>Vaishali Nagar</b><br>
			  <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3558.0547805694996!2d75.7413212!3d26.901756499999994!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396db51d7e983483%3A0x80687443d6f95370!2sPrecision%20Path%20Lab%20%7C%20Best%20Diagnostic%20Centre%20%7C%20Full%20body%20Checkup%20in%20Vaishali%20Nagar%2C%20Jaipur!5e0!3m2!1sen!2sin!4v1690892304193!5m2!1sen!2sin" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
           </div>
				  </div>
          </div>

        </div>
      </div>
    </div>

    <div class="container d-md-flex py-4">

     <div class="me-md-auto text-center text-md-start">
        <div class="copyright">
          &copy; Copyright 2025 <strong><span>Precision Path Lab</span></strong>. All Rights Reserved.
        </div>
        <!-- <div class="credits">
          Designed by <a href="https://thecogent.in/best-digital-marketing-company-in-jaipur">Digital Marketing Company in Jaipur</a>
        </div> -->
      </div>
      <div class="social-links text-center text-md-right pt-3 pt-md-0">
        <a href="https://www.facebook.com/precisonpathlab" class="facebook"><i class="bx bxl-facebook"></i></a>
        <a href="https://www.instagram.com/precisionpathlab/" class="instagram"><i class="bx bxl-instagram"></i></a>
      </div>
    </div>
  </footer><!-- End Footer -->
	  <!-- WhatsApp widget code -->
  <div class="whatsapp-widget">
    <a href="https://wa.me/+917230002896" target="_blank">
      <img src="../img/whatsapp1.png" id="whatsapp" alt="WhatsApp" width="50px">
	 
		  <b class="text-white">Let's chat</b>
	  
    </a>
	 
  </div>
 <!-- <div id="preloader"></div>-->
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
	    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	
		<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
	
<script>
$(document).ready(function(){
	var headerheight=jQuery('#header').height();
	var topbarheight=jQuery('#topbar').height();
	var top_section=headerheight+topbarheight+"px";
	$('#carouselExampleDark').css({"padding-top":top_section});
});	
	
	</script>
<script>
   $(function(){
	var i= 0;
	//when the next button is clicked on
	$('.nextCircle').on("click", function(){
      //increase the display picture index by 1
		i = i + 1;
		//if we are at the end of the image queue, set the index back to 0
		if (i == $('.swiper-slide.slide').length) {
			i=0;
		}
		//set current image and previous image
		var currentImg = $('.swiper-slide.slide').eq(i);
		var prevImg = $('.swiper-slide.slide').eq(i-1);
		//call function to animate the rotation of the images to the right
		animateImage(prevImg, currentImg);	
	});
	//when the previous button is clicked on
	$('.prevCircle').on("click", function(){
		//if we are at the beginning of the image queue, set the previous image to the first image and the current image to the last image of the queue
		if (i==0) {	
			prevImg = $('.swiper-slide.slide').eq(0);
			i=$('.swiper-slide.slide').length-1;
			currentImg = $('.swiper-slide.slide').eq(i);
		}
		//decrease the display picture index by 1
		else {
			i=i-1;
			//set current and previous images
			currentImg = $('.swiper-slide.slide').eq(i);
			prevImg = $('.swiper-slide.slide').eq(i+1);
		}
		//call function to animate the rotation of the images to the left
		animateImageLeft(prevImg, currentImg);	
	});
	//function to animate the rotation of the images to the left
	function animateImageLeft(prevImg, currentImg) {
		//move the image to be displayed off the visible container to the right
		currentImg.css({"left":"100%"});
		//slide the image to be displayed from off the container onto the visible container to make it slide from the right to left
		currentImg.animate({"left":"0%"}, 1000);
		//slide the previous image off the container from right to left
		prevImg.animate({"left":"-100%"}, 1000);
	}
	//function to animate the rotation of the images to the right
	function animateImage(prevImg, currentImg) {
		//move the image to be displayed off the container to the left
		currentImg.css({"left":"-100%"});
		//slide the image to be displayed from off the container onto the container to make it slide from left to right
		currentImg.animate({"left":"0%"}, 1000);
		//slide the image from on the container to off the container to make it slide from left to right
		prevImg.animate({"left":"100%"}, 1000);	
	}
});
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
    <script>
        $(function () {
            // Owl Carousel
            var owl = $(".owl-carousel.home-slider");
            owl.owlCarousel({
                items: 1,
                margin: 10,
                loop: true,
                nav: true,
                autoplay: true,
                        autoplayTimeout: 300,
                        autoplayHoverPause: true
            });
        });

    </script>
	<script>
    // Add event listener to show/hide the WhatsApp widget on scroll
    window.addEventListener('scroll', function() {
      var whatsappWidget = document.querySelector('.whatsapp-widget');
      var scrollPosition = window.scrollY || window.pageYOffset;

      if (scrollPosition > 100) {
        whatsappWidget.style.right = '15px';
      } else {
        whatsappWidget.style.right = '-170px';
      }
    });
  </script>
	  <script>
        const button = document.getElementById("read-more-button");
        const hiddenText = document.getElementById("hidden-text");

        button.addEventListener("click", function () {
            if (hiddenText.style.display === "none") {
                hiddenText.style.display = "block";
                button.textContent = "Read Less";
            } else {
                hiddenText.style.display = "none";
                button.textContent = "Read More";
            }
        });
    </script>
		  <script>
  $(function() {

  $('.txtNumeric1').keydown(function (e) {
  
    if (e.shiftKey || e.ctrlKey || e.altKey) {
    
      e.preventDefault();
      
    } else {
    
      var key = e.keyCode;
      
      if (!((key == 8) || (key == 32) || (key == 46) || (key >= 35 && key <= 40) || (key >= 65 && key <= 90))) {
      
        e.preventDefault();
        
      }

    }
    
  });
  
});
</script>
<script type="text/javascript">
         
        jQuery(document).ready(function () {    
 
            jQuery( '.numbersOnly' ).keypress(function (e) {   
  
                var charCode = (e.which) ? e.which : event.keyCode    
                if (String.fromCharCode(charCode).match(/[^0-9]/g))    
                    return false;                        
            });    
 
        });   
  
    </script>
	

</body>

</html>	