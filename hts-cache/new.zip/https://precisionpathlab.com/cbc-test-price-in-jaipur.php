<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=0" /> 

  <title>CBC (Complete Blood Count) Test Price In Jaipur @250 </title>
  <meta content="Get affordable CBC (Complete Blood Count) test prices in Jaipur at Precision Pathlab. Find accurate and up-to-date pricing information for CBC tests in Jaipur. " name="description">
  <meta content="" name="keywords">
	<meta property="og:image" content="https://precisionpathlab.com/assets/img/pathlab.png">
	
	<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-D8QG004XC3"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-D8QG004XC3');
</script>

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

 <link rel="canonical" href="https://precisionpathlab.com/cbc-test-price-in-jaipur.php">
  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
 
</head>

<body>

  <!-- ======= Top Bar ======= -->
  <div id="topbar" class="d-flex align-items-center fixed-top">
    <div class="container d-flex justify-content-between">
      <div class="contact-info d-flex align-items-center">
        <i class="bi bi-envelope"></i> <a href="mailto:contact@example.com">info@precisionpathlab.com</a>
        <i class="bi bi-phone"></i> +91-7230002896 
      </div>
      <div class="d-none d-lg-flex social-links align-items-center">
        <a href="https://www.facebook.com/precisonpathlab" class="facebook"><i class="bx bxl-facebook"></i></a>
        <a href="https://www.instagram.com/precisionpathlab/" class="instagram"><i class="bi bi-instagram"></i></a>
      </div>
    </div>
  </div>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center">

		<a href="https://precisionpathlab.com/" class="logo me-auto"><img src="assets/img/pathlab.png" alt="Precision Pathlab" class="img-fluid"></a>

		<nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="nav-link scrollto" href="https://precisionpathlab.com/">Home</a></li>
          <li><a class="nav-link scrollto" href="about.php">About Us</a></li>
          <li><a class="nav-link scrollto active" href="book-test.php">Book a Test</a></li>
          <li><a class="nav-link scrollto" href="full-body-check-up-in-jaipur.php">Health Packages</a></li>
          <li><a class="nav-link scrollto" href="laboratories.php">Our Laboratories</a></li>
          <li><a class="nav-link scrollto" href="home-collection.php">Home Collection</a></li>
          <li><a class="nav-link scrollto" href="contact.php">Contact</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

<a href="http://175.111.130.182/precision/design/online_lab/default.aspx" target="_blank" class="appointment-btn scrollto"><span class="d-none d-md-inline">Online</span> Report</a>
    </div>
  </header><!-- End Header -->
	<div style="height:130px;"></div>
	<div class="container">
		
		<div class="row">
			<div class="col-lg-6 mt-4">
			<form style="box-shadow:1px 1px 1px 3px; border-radius:20px; padding:15px;">
  <div class="mb-3">
	  <h3><b class="text-danger">Complete Blood Count (CBC test)</b></h3>
	  <b>22 Observations included</b>
   <hr>
	  <div class="row">
		  <div class="col-5">
		  <h5><b>MRP -  ₹250</b></h5> 
		  </div>
		  <div class="col-7">
			 <b>Recommended For</b><br>  <b><img src="img/male.svg">  Male  &nbsp; <img src="img/female.svg">  Female</b>
			 
		  </div>
	  </div>
  </div>
	<hr>
  <div class="mb-3">
    <div class="row">
		  <div class="col-5">
		  <b>Age Group</b><br>
			  <b><img src="img/group.svg"> 0-99 Years</b>
		  </div>
		 <div class="col-7">
		  <b>Report Generation Time</b><br>
			  <b><img src="img/watch.svg">  Same Day</b>
		  </div>
		 
	  </div>
  </div><hr>
				<div class="mb-3">
    <div class="row">
		  <div class="col-12">
			  <b>Collaction At</b><br>
<img src="img/home_visit.svg"> Home &nbsp;  <img src="img/labflask.svg"> Lab  

		  </div>
		
		 
	  </div>
  </div><hr>
  <a class="text-white btn btn-primary w-100" href="#appointment" >Book Now</a>
</form>
			</div>
			<div class="col-lg-6 mt-4">
				<h1>CBC (Complete Blood Count) Test Price In Jaipur </h1>
				<p style="border:solid 1px black; padding:5px;">Knowing the cost is essential if you're living in Jaipur and need to undergo a CBC (Complete Blood Count) test. The CBC test is a routine blood test that measures various components of your blood and is usually ordered as part of a regular checkup or to help diagnose a range of conditions. We aim to provide you with essential information about the CBC test price in Jaipur, helping you make an informed decision about your appointment.</p>
			
				
				<img src="img/medical.png" height="70">
					<img src="img/medical-team.png" style="padding-left:40px;" height="70">
				<img src="img/blood-test.png" style="padding-left:40px;" height="70">
				
			</div>
			<div class="row mt-4">
				<div class="col-12">
					<h3>Overview of the CBC (Complete Blood Count) Test</h3>
				<p>The CBC (Complete Blood Count) test is a blood test that measures different components of your blood. This test can detect infections, anemia, leukemia, and blood cancers. The Blood test price in Jaipur may vary from one diagnostic center to another. A vein is pricked, and your blood is analyzed in a laboratory. The test results can provide valuable insights into your overall health and help diagnose underlying conditions. </p>
				<h3>When is the CBC Test Prescribed?</h3>
				<p>The CBC (Complete Blood Count) Test is one of doctors' and medical practitioners' most commonly prescribed blood tests. In addition to evaluating health conditions and diseases. Some of the common reasons why doctors prescribe the CBC test include the following:</p>
				</div>
			</div>
		</div><br>
		<div class="row">
			<div class="col-12">
				<table class="table table-light table-striped">
  <thead>
    <tr>
      <th scope="col">Sno</th>
      <th scope="col">CBC Test Prescribed For:</th>
      <th scope="col">Reasons for Prescribing:</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>General health check-up</td>
      <td>Routine screening for overall health assessment</td>
      
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Diagnosis of illnesses</td>
      <td>Diagnosis of illnesses	Determining the cause of symptoms or abnormalities</td>
     
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Monitoring treatments</td>
      <td>Tracking the progress of ongoing medical interventions</td>
    </tr>
	 <tr>
      <th scope="row">4</th>
      <td>Preoperative evaluation</td>
      <td>Assessing baseline health before surgical procedures</td>
    </tr>
	   <tr>
      <th scope="row">5</th>
      <td>Monitoring chronic conditions</td>
      <td>Monitoring chronic conditions	Managing and tracking long-term medical conditions</td>
    </tr>
	  <tr>
      <th scope="row">6</th>
      <td>Anemia detection</td>
      <td>Identifying and evaluating different types of anemia</td>
    </tr>
	   <tr>
      <th scope="row">7</th>
      <td>Infection evaluation</td>
      <td>Detecting and monitoring infections in the body</td>
    </tr>
	   <tr>
      <th scope="row">8</th>
      <td>Immune system disorders</td>
      <td>Assessing immune function and related abnormalities</td>
    </tr>
	  <tr>
      <th scope="row">9</th>
      <td>Bleeding or clotting disorders</td>
      <td>Evaluating blood clotting factors and platelet count</td>
    </tr>
	  <tr>
      <th scope="row">10</th>
      <td>Unexplained symptoms</td>
      <td>Unexplained symptoms	Investigating unexplained fatigue, weakness, etc.</td>
    </tr>
	  <tr>
      <th scope="row">11</th>
      <td>Follow-up care</td>
      <td>Monitoring ongoing conditions or recovery progress</td>
    </tr>
  </tbody>
</table>
			</div>
		</div>
			 			<div class="row" id="appointment1" >
				<div class="col-lg-8">
					<h3>Preparation for the CBC Test </h3>
					<p>There are no specific dietary or lifestyle restrictions before a CBC test. However, informing your healthcare provider about any medication or supplements you may be taking is recommended, as they may affect the test results. Additionally, wearing comfortable and loose-fitting clothing for the blood draw is vital. CBC test prices in Jaipur may vary based on your chosen laboratory or hospital</p>
					<p>Precision Path Lab has experts in CBC (Complete Blood Count) tests who have 10 years of experience. This is why Precision Path Lab is considered the <a href="https://precisionpathlab.com/">best path lab in Jaipur</a>.</p>
					<h3>Time Required for CBC Test Report </h3>
					<p>The time required for a CBC (Complete Blood Count) test report can vary depending on several factors. You will usually receive the results. However, this timeframe may be influenced by factors such as the laboratory's workload, the urgency of the test, and the availability of advanced technology. Sometimes, a preliminary report may be available within a few hours if the test is conducted in an emergency. The most notable feature of Precision Path Lab is that the reports are available on the same day. </p>
				</div>
				<div class="col-lg-4"  id="appointment">
					<form method="post" action="https://precisionpathlab.com/cbc-test-price-in-jaipur.php#appointment1" style="box-shadow:1px 1px 1px 3px; border-radius:20px; padding:10px;  background: linear-gradient(to right, #ffcc99 0%, #ff9999 100%);">	
												<h4 class="text-danger text-center"><b>Book Your Test Today</b></h4>
						<div class="mb-3">
						<input type="text" class="form-control" placeholder="Your Name*" id="text" name="name" aria-describedby="textHelp" required>
					  </div>
						 <div class="mb-3">
						<input type="text" class="form-control" id="number" name="phone" placeholder="Phone Number*" required>
					  </div>
					  <div class="mb-3">
						<input type="email" class="form-control" id="exampleInputEmail1" name="email" placeholder="Your Email (Optional)" aria-describedby="emailHelp">
						  <div id="emailHelp" class="form-text"><b class="text-danger">By Submitting You Agree To Our T&C.</b></div>
					  </div>
					 
					  <button type="submit" name="submit2" class="btn btn-primary">Submit</button>
</form>
				</div>
			</div>
			<div class="row mt-3">
				<div class="col-12">
					<h3>Complete Blood Count Normal Range</h3>
					<h5><b>Here's the normal range for a Complete Blood Count (CBC) test</b></h5>
					<table class="table table-light table-striped">
  <thead>
    <tr>
      <th scope="col">Sno</th>
      <th scope="col">Component</th>
      <th scope="col">Normal Range</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>White Blood Cells</td>
      <td>4,500 to 11,000 cells/microliter</td>
      
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Red Blood Cells</td>
      <td>Male: 4.5 to 5.5 million cells/microliter<br>Female: 4.0 to 5.0 million cells/microliter</td>
     
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Hemoglobin</td>
      <td>Male: 13.5 to 17.5 grams/deciliter<br>Female: 12.0 to 15.5 grams/deciliter</td>
    </tr>
	 <tr>
      <th scope="row">4</th>
      <td>Hematocrit</td>
      <td>Male: 38.8% to 50.0%<br>Female: 34.9% to 44.5%</td>
    </tr>
	   <tr>
      <th scope="row">5</th>
      <td>Platelets</td>
      <td>150,000 to 450,000 platelets/microliter</td>
    </tr>
	  <tr>
      <th scope="row">6</th>
      <td>Mean Corpuscular Volume (MCV)</td>
      <td>80 to 95 femtoliters</td>
    </tr>
	   <tr>
      <th scope="row">7</th>
      <td>Mean Corpuscular Hemoglobin (MCH)</td>
      <td>27 to 33 picograms</td>
    </tr>
	   <tr>
      <th scope="row">8</th>
      <td>Mean Corpuscular Hemoglobin Concentration (MCHC)</td>
      <td>32 to 36 grams/deciliter</td>
    </tr>
	  <tr>
      <th scope="row">9</th>
      <td>Red Cell Distribution Width (RDW)</td>
      <td>11.5% to 14.5%</td>
    </tr>
	 
  </tbody>
</table>
					
				</div>
			</div>
				
					<div class="row mt-3">
						<div class="col-12">
							<h3 class="text-center">FAQs For CBC Test Price in Jaipur</h3>
							<div class="accordion" id="accordionExample">
  <div class="accordion-item">
    <h2 class="accordion-header">
      <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
       Q1. How much does a CBC cost per test? 
      </button>
    </h2>
    <div id="collapseOne" class="accordion-collapse collapse show" data-bs-parent="#accordionExample">
      <div class="accordion-body">
        The cost of a CBC (Complete Blood Count) test can vary depending on location, healthcare provider, and insurance coverage. On average, a CBC test can range from 250Rs to 750Rs. Specific pricing for CBC tests in Jaipur can be obtained by contacting local laboratories or healthcare facilities directly.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
        Q2. How long is the validity of CBC?  
      </button>
    </h2>
    <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
      <div class="accordion-body">
       A CBC test does not have an expiration date or validity period. The results of a CBC reflect the blood parameters at the time the test was performed. However, suppose significant changes in a person's health condition or new symptoms arise. It may be necessary to repeat the CBC test to obtain updated results.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
       Q3.  What is the use of CBC blood tests? 
      </button>
    </h2>
    <div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
      <div class="accordion-body">
       A CBC blood test assesses various aspects of a person's blood, including red and white blood cell counts, hemoglobin, hematocrit, and platelet count. It helps evaluate overall health, diagnose medical conditions, monitor treatments, detect infections, assess anemia, and identify blood disorders.
      </div>
    </div>
  </div>
	   <div class="accordion-item">
    <h2 class="accordion-header">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
        Q4. Can I do a CBC test at home? 
      </button>
    </h2>
    <div id="collapseFour" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
      <div class="accordion-body">
       Typically, a CBC test requires specialized equipment and trained healthcare professionals to collect and analyze the blood sample. Thus, performing a CBC test at home with the necessary equipment and expertise is only possible. Therefore, visiting a healthcare facility or laboratory for a CBC test is recommended.
      </div>
    </div>
  </div>
		    <div class="accordion-item">
    <h2 class="accordion-header">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
        Q5. Which time is best for a CBC test? 
      </button>
    </h2>
    <div id="collapseFive" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
      <div class="accordion-body">
       The timing for a CBC test is typically unrestricted to a specific time of day. However, if applicable, consult with your healthcare provider regarding any detailed instructions regarding fasting requirements or timing for the test.
      </div>
    </div>
  </div>
				 <div class="accordion-item">
    <h2 class="accordion-header">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
         Q6. Who needs a CBC test? 
      </button>
    </h2>
    <div id="collapseSix" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
      <div class="accordion-body">
        Healthcare providers may order a CBC test for various reasons. It is commonly performed as part of routine health checkups for diagnosing illnesses, monitoring chronic conditions, assessing preoperative health, evaluating unexplained symptoms, and managing ongoing treatments. The healthcare provider determines the need for a CBC test based on individual circumstances.
      </div>
    </div>
  </div>
					  <div class="accordion-item">
    <h2 class="accordion-header">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">
        Q7. Does CBC show vitamin D deficiency? 
      </button>
    </h2>
    <div id="collapseSeven" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
      <div class="accordion-body">
        No, a CBC test does not directly measure vitamin D levels. To assess vitamin D deficiency, a separate blood test called a 25-hydroxyvitamin D test is required.
      </div>
    </div>
  </div>
						   <div class="accordion-item">
    <h2 class="accordion-header">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseEight" aria-expanded="false" aria-controls="collapseEight">
         Q8. How do you read a CBC result? 
      </button>
    </h2>
    <div id="collapseEight" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
      <div class="accordion-body">
        Reading a CBC result requires interpretation by a healthcare professional. They analyze the various components of the CBC, such as hemoglobin, hematocrit, platelet count, and other parameters, considering the individual's medical history, symptoms, and context. CBC tests can be referred to as CBC experts.
      </div>
    </div>
  </div>
</div>
						</div>
					</div>
		</div>
		
	

  <!-- ======= Footer ======= -->
 <footer id="footer">

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-contact">
            <h3>PRECISION HOUSE</h3>
            <p>
			  <i class="bi bi-geo-alt"></i> :
			  72/2, Shipra Path, Mansarovar<br>
 			  Jaipur 302020 (India)<br><br>
              <i class="bi bi-phone"></i> : +91 8696222281, 8696222678<br>
              <i class="bi bi-envelope"></i> : info@precisionpathlab.com<br>
            </p><br>

			  <h5>Our Timing</h5>
			  <p><b>Monday to Saturday </b><br>
 					8:00 AM to 8:30 PM<br>
				 <b>Sunday</b><br>
					8:00 AM to 2:30 PM</p>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
            <h4>Quick Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="https://precisionpathlab.com/">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="about.php">About us</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="full-body-check-up-in-jaipur.php">Health Packages</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="laboratories.php">Our Laboratories</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Home Collection</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="https://precisionpathlab.com/blog/">Our Blog</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="contact.php">Contact Us</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Our Services</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Pathology Testing</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Microscopic Testing</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">X-Ray</a></li>
			 <li><i class="bx bx-chevron-right"></i> <a href="https://precisionpathlab.com/feedback.php">Feedback</a></li>
            </ul>
          </div>

          <div class="col-lg-4 col-md-6 footer-newsletter">
            <h4 class="text-center">Reach Us</h4>
			  <div class="row">
				  <div class="col-6">
					  <b>Mansarovar</b><br>
			  <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14238.140506209242!2d75.7730997!3d26.8547344!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396db5230f2899a5%3A0xde62d7d0e085d8c3!2sPrecision%20Path%20Lab%20%7C%20Path%20Lab%20in%20Jaipur%20%7C%20Mansarovar!5e0!3m2!1sen!2sin!4v1680676109737!5m2!1sen!2sin" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
           </div>
				   <div class="col-6">
					   <b>Vaishali Nagar</b><br>
			  <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3558.0547805694996!2d75.7413212!3d26.901756499999994!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396db51d7e983483%3A0x80687443d6f95370!2sPrecision%20Path%20Lab%20%7C%20Best%20Diagnostic%20Centre%20%7C%20Full%20body%20Checkup%20in%20Vaishali%20Nagar%2C%20Jaipur!5e0!3m2!1sen!2sin!4v1690892304193!5m2!1sen!2sin" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
           </div>
				  </div>
          </div>

        </div>
      </div>
    </div>

    <div class="container d-md-flex py-4">

      <div class="me-md-auto text-center text-md-start">
        <div class="copyright">
          &copy; Copyright 2025 <strong><span>Precision Path Lab</span></strong>. All Rights Reserved.
        </div>
        <!--<div class="credits">
          Designed by <a href="https://thecogent.in/best-digital-marketing-company-in-jaipur">Digital Marketing Company in Jaipur</a>
        </div>-->
      </div>
      <div class="social-links text-center text-md-right pt-3 pt-md-0">
        <a href="https://www.facebook.com/precisonpathlab" class="facebook"><i class="bx bxl-facebook"></i></a>
        <a href="https://www.instagram.com/precisionpathlab/" class="instagram"><i class="bx bxl-instagram"></i></a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
	<a href="https://api.whatsapp.com/send?phone=+917230002896%27&amp;text=Hey" target="_blank" class="whatsaap-icon d-flex align-items-center justify-content-center"><i class="bi bi-whatsapp"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>