<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=0" /> 

  <title> Book a Test Online | Precision Path Lab</title>
  <meta content="Easily book a test online at Precision Path Lab for convenient and reliable diagnostic services. Explore our comprehensive range of tests and schedule an appointment in just a few clicks" name="description">
  <meta content="" name="keywords">
	<meta property="og:image" content="https://precisionpathlab.com/assets/img/pathlab.png">
	
	<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-D8QG004XC3"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-D8QG004XC3');
</script>

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

 <link rel="canonical" href="https://precisionpathlab.com/book-test.php">
  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
	        <link href = "https://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css"
         rel = "stylesheet">

 <style>
	 @media screen and (min-width: 992px) {
  .medium-height {
		 height:400px;
	 }
}
	 .btn2:hover .btn1{
		color:blue;
		 background-color:white;
	 }
	 .btn2:hover .btn3
	 {
	 	color:white;
	 }
	 

	 </style>
	      <link href = "https://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css"
         rel = "stylesheet">
      <script src = "https://code.jquery.com/jquery-1.10.2.js"></script>
      <script src = "https://code.jquery.com/ui/1.10.4/jquery-ui.js"></script>

      <!-- Javascript -->
      <script>
         $(function() {
            $( "#datepicker-1" ).datepicker();
         });
      </script>
	<style>
    /* CSS for the WhatsApp widget */
    .whatsapp-widget {
      position: fixed;
      bottom: 75px;
		width:150px;
		background-color:#00a884;
		border-radius:5%;
      right: -170px; /* Initially hidden */
      z-index: 9999;
      transition: right 0.3s ease-in-out;
    }
    .whatsapp-widget:hover {
      right: 20px; /* Display on hover */
    }
    .whatsapp-widget img {
      width: 50px;
      height: 50px;
    }
  </style>

</head>

<body>

  <!-- ======= Top Bar ======= -->
  <div id="topbar" class="d-flex align-items-center fixed-top">
    <div class="container d-flex justify-content-between">
      <div class="contact-info d-flex align-items-center">
        <i class="bi bi-envelope"></i> <a href="mailto:info@precisionpathlab.com">info@precisionpathlab.com</a>
        <i class="bi bi-phone"></i> +91-7230002896 
      </div>
      <div class="d-none d-lg-flex social-links align-items-center">
       
        <a href="https://www.facebook.com/precisonpathlab" class="facebook"><i class="bx bxl-facebook"></i></a>
        <a href="https://www.instagram.com/precisionpathlab/" class="instagram"><i class="bi bi-instagram"></i></a>
      </div>
    </div>
  </div>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center">

		<a href="https://precisionpathlab.com/" class="logo me-auto"><img src="assets/img/pathlab.png" alt="Precision Pathlab" class="img-fluid"></a>

		<nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="nav-link scrollto" href="https://precisionpathlab.com/">Home</a></li>
          <li><a class="nav-link scrollto" href="about.php">About Us</a></li>
          <li><a class="nav-link scrollto active" href="book-test.php">Book a Test</a></li>
          <li><a class="nav-link scrollto" href="full-body-check-up-in-jaipur.php">Health Packages</a></li>
          <li><a class="nav-link scrollto" href="laboratories.php">Our Laboratories</a></li>
          <li><a class="nav-link scrollto" href="home-collection.php">Home Collection</a></li>
          <li><a class="nav-link scrollto" href="contact.php">Contact</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

<a href="http://175.111.130.182/precision/design/online_lab/default.aspx" target="_blank" class="appointment-btn scrollto"><span class="d-none d-md-inline">Online</span> Report</a>
    </div>
  </header><!-- End Header -->

   <!-- ======= Breadcrumbs Section ======= -->
    <section class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
			<div class="left-banner">
			<h2 class="mb-3">Book a Test</h2>
			</div>
          <ol>
            <li><a href="index.php">Home</a></li>
            <li>Book a Test</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs Section -->

  <main id="main">

    <!-- ======= Services Section ======= -->
    <section id="services" class="services">
      <div class="container">

        <div class="section-title">
          <h2>Online Test Booking</h2>
          <p class="text-start">The prospect of spending hours in a queue at the diagnostic lab or the hospital deters many or at least prompts them to defer stepping out for diagnostic tests.<br>
Appreciating the importance of health tests and understanding the need for making diagnostic services user-friendly, Precision Path Lab offers the sheer convenience of Online Test booking and Home Sample Collection facilities to its user's. </p>
        </div>
		  <div class="row ">
			  <div class="col-lg-12" style="alignment-baseline: center">
				  <div class="form-check form-switch">
  <input class="form-check-input"  name="switch"  onchange="tabSwithch();" type="checkbox" role="switch" id="packages">
  <label class="form-check-label" for="flexSwitchCheckDefault">Health Packages</label>
</div>
			 <!-- <a href="health-packages.php" class="appointment-btn scrollto" ><span class="d-none d-md-inline">Health </span> Packages</a> -->
			  </div>
		  </div><br>

        <div class="row">
          <div class="col-12 col-lg-3 col-md-6 mb-3 btn2 ">
            <div class="icon-box2 h-100">
              <h4><a href="https://precisionpathlab.com/cbc-test-price-in-jaipur.php">COMPLETE BLOOD COUNT (CBC)</a></h4>
              <p> <b>Report Delivery:</b> Same Day</p><br>

				<h3 class="btn3">Rs. 250/-</h3>
				<br>
			  <a class="appointment-btn btn1 scrollto" id="COMPLETE-BLOOD-COUNT"  data-bs-toggle="modal" data-bs-target="#exampleModal" ><span class="d-none d-md-inline"></span>Book Test</a>
            </div>
          </div>

          <div class="col-12 col-lg-3 col-md-6 mb-3 btn2">
            <div class="icon-box2 h-100">
              <h4><a href="">ESR (FULLY AUTOMATED) </a></h4>
              <p> <b>Report Delivery:</b> Same Day</p><br>

				<h3 class="btn3">Rs. 140/-</h3>
				<br>
			  <a href="#appointment" id="ESR" class="appointment-btn btn1 scrollto" data-bs-toggle="modal" data-bs-target="#exampleModal" ><span class="d-none d-md-inline"></span>Book Test</a>
            </div>
          </div>

          <div class="col-12 col-lg-3 col-md-6 mb-3 btn2">
            <div class="icon-box2 h-100">
              <h4><a href="">KFT (Kidney Panel)</a></h4>
              <p> <b>Report Delivery:</b> Same Day</p><br>

				<h3 class="btn3">Rs. 550/-</h3>
				<br>
			  <a href="#appointment" id="KFT-kidney-Panel" class="appointment-btn btn1 scrollto" data-bs-toggle="modal" data-bs-target="#exampleModal" ><span class="d-none d-md-inline"></span>Book Test</a>
            </div>
          </div>
			
		  <div class="col-12 col-md-6 col-lg-3 btn2">
            <div class="icon-box2 h-100">
              <h4><a href="">LFT (Liver Panel)</a></h4>
              <p> <b>Report Delivery:</b> Same Day</p><br>

				<h3 class="btn3">Rs. 550/-</h3>
				<br>
			  <a href="#appointment" id="LFT" class="appointment-btn btn1 scrollto" data-bs-toggle="modal" data-bs-target="#exampleModal" ><span class="d-none d-md-inline"></span>Book Test</a>
            </div>
          </div>

        </div><br>

		  <div class="row">
          <div class="col-12 col-lg-3 col-md-6 mb-3 btn2 ">
            <div class="icon-box2 h-100">
              <h4><a href="">BLOOD GROUP</a></h4>
              <p> <b>Report Delivery:</b> Same Day</p><br>

				<h3 class="btn3">Rs. 150/-</h3>
				<br>
			  <a href="#appointment" id="BLOOD-GROUP" class="appointment-btn btn1 scrollto" data-bs-toggle="modal" data-bs-target="#exampleModal" ><span class="d-none d-md-inline"></span>Book Test</a>
            </div>
          </div>

          <div class="col-12 col-lg-3 col-md-6 mb-3 btn2">
            <div class="icon-box2 h-100">
              <h4><a href="">GLYCOSYLATED HB (HbA1c)  </a></h4>
              <p> <b>Report Delivery:</b> Same Day</p><br>

				<h3 class="btn3">Rs. 500/-</h3>
				<br>
			  <a href="#appointment" id="GLYCOSYLATED-HB" class="appointment-btn btn1 scrollto" data-bs-toggle="modal" data-bs-target="#exampleModal" ><span class="d-none d-md-inline"></span>Book Test</a>
            </div>
          </div>

          <div class="col-12 col-lg-3 col-md-6 mb-3 btn2">
            <div class="icon-box2 h-100">
              <h4><a href="">VITAMIN B12</a></h4>
              <p> <b>Report Delivery:</b> Same Day</p><br>

				<h3 class="btn3">Rs. 800/-</h3>
				<br>
			  <a href="#appointment" id="VITAMIN-B12" class="appointment-btn btn1 scrollto" data-bs-toggle="modal" data-bs-target="#exampleModal" ><span class="d-none d-md-inline"></span>Book Test</a>
            </div>
          </div>
			
		  <div class="col-12 col-lg-3 col-md-6 btn2">
            <div class="icon-box2 h-100">
              <h4><a href="">TSH (Thyroid Stimulating Hormone)</a></h4>
              <p> <b>Report Delivery:</b> Same Day</p><br>

				<h3 class="btn3">Rs. 260/-</h3>
				<br>
			  <a href="#appointment" id="Thyroid-Stimulating-Hormone" class="appointment-btn btn1 scrollto" data-bs-toggle="modal" data-bs-target="#exampleModal" ><span class="d-none d-md-inline"></span>Book Test</a>
            </div>
          </div>

        </div><br>

		  <div class="row">
          <div class="col-12 col-lg-3 col-md-6 btn2 mb-3">
            <div class="icon-box2 h-100">
              <h4><a href="">SMALL BIOPSY </a></h4>
              <p> <b>Report Delivery:</b> Same Day</p><br>

				<h3 class="btn3">Rs. 850/-</h3>
				<br>
			  <a href="#appointment" id="SMALL-BIOPSY" class="appointment-btn btn1 scrollto" data-bs-toggle="modal" data-bs-target="#exampleModal" ><span class="d-none d-md-inline"></span>Book Test</a>
            </div>
          </div>

          <div class="col-12 col-lg-3 col-md-6 btn2 mb-3">
            <div class="icon-box2 h-100">
              <h4><a href="">URINE ROUTINE EXAMINATION   </a></h4>
              <p> <b>Report Delivery:</b> Same Day</p><br>

				<h3 class="btn3">Rs. 170/-</h3>
				<br>
			  <a href="#appointment" id="URINE-ROUTINE-EXAMINATION" class="appointment-btn btn1 scrollto" data-bs-toggle="modal" data-bs-target="#exampleModal" ><span class="d-none d-md-inline"></span>Book Test</a>
            </div>
          </div>

          <div class="col-12 col-lg-3 col-md-6 mb-3 btn2">
            <div class="icon-box2 h-100">
              <h4><a href="">LIPID PROFILE - Serum</a></h4>
              <p> <b>Report Delivery:</b> Same Day</p><br>

				<h3 class="btn3">Rs. 550/-</h3>
				<br>
			  <a href="#appointment" id="LIPID-PROFILE-Serum" class="appointment-btn btn1 scrollto" data-bs-toggle="modal" data-bs-target="#exampleModal" ><span class="d-none d-md-inline"></span>Book Test</a>
            </div>
          </div>
			
		  <div class="col-12 col-lg-3 col-md-6 btn2 ">
            <div class="icon-box2 h-100">
              <h4><a href="">CREATININE</a></h4>
              <p> <b>Report Delivery:</b> Same Day</p><br>

				<h3 class="btn3">Rs. 170/-</h3>
				<br>
			  <a href="#appointment" id="CREATININE" class="appointment-btn btn1 scrollto" data-bs-toggle="modal" data-bs-target="#exampleModal" ><span class="d-none d-md-inline"></span>Book Test</a>
            </div>
          </div>

        </div><br>
		  <div class="row">
          <div class="col-12 col-lg-3 col-md-6 mb-3 btn2 box">
            <div class="icon-box2 h-100">
              <h4><a href="">BLOOD SUGAR RANDOM  </a></h4>
              <p> <b>Report Delivery:</b> Same Day</p><br>

				<h3 class="btn3">Rs. 60/-</h3>
				<br>
			  <a href="#appointment" id="BLOOD-SUGAR-RANDOM" class="appointment-btn btn1 scrollto" data-bs-toggle="modal" data-bs-target="#exampleModal" ><span class="d-none d-md-inline"></span>Book Test</a>
            </div>
          </div>

          <div class="col-12 col-lg-3 col-md-6 mb-3 btn2">
            <div class="icon-box2 h-100">
              <h4><a href="">FT3,FT4,TSH  </a></h4>
              <p> <b>Report Delivery:</b> Same Day</p><br>

				<h3 class="btn3">Rs. 700/-</h3>
				<br>
			  <a href="#appointment" id="FT3-FT4-TSH" class="appointment-btn btn1 scrollto" data-bs-toggle="modal" data-bs-target="#exampleModal" ><span class="d-none d-md-inline"></span>Book Test</a>
            </div>
          </div>

          <div class="col-12 col-lg-3 col-md-6 mb-3 btn2">
            <div class="icon-box2 h-100">
              <h4><a href="">SGOT (AST) </a></h4>
              <p> <b>Report Delivery:</b> Same Day</p><br>

				<h3 class="btn3">Rs. 150/-</h3>
				<br>
			  <a href="#appointment" id="SGOT-AST" class="appointment-btn btn1 scrollto" data-bs-toggle="modal" data-bs-target="#exampleModal" ><span class="d-none d-md-inline"></span>Book Test</a>
            </div>
          </div>
			
		  <div class="col-12 col-md-6 col-lg-3 mb-3 btn2 ">
            <div class="icon-box2 h-100 ">
              <h4><a href="">SGPT (ALT) </a></h4>
              <p> <b>Report Delivery:</b> Same Day</p><br>

				<h3 class="btn3">Rs. 150/-</h3>
				<br>
			  <a href="#appointment" id="SGPT" class="appointment-btn btn1 scrollto" data-bs-toggle="modal" data-bs-target="#exampleModal" ><span class="d-none d-md-inline"></span>Book Test</a>
            </div>
          </div>
			  
			

        </div>
		   <div class="row mt-4">
			     <div class="col-12 col-md-6 col-lg-3 mb-3 btn2">
            <div class="icon-box2 h-100 ">
              <h4><a href="">Biopsy Test </a></h4>
              <p> <b>Report Delivery:</b> 2-3 Days</p><br>

				<!-- <h3 class="btn3">Rs. 150/-</h3> -->
				<br>
			  <a href="#appointment" id="biospy" class="appointment-btn btn1 scrollto" data-bs-toggle="modal" data-bs-target="#exampleModal" ><span class="d-none d-md-inline"></span>Book Test</a>
            </div>
          </div>
			      <div class="col-12 col-md-6 col-lg-3 mb-3 btn2">
            <div class="icon-box2 h-100 ">
              <h4><a href="">Swine Flu Test </a></h4>
              <p> <b>Report Delivery:</b> Same Day</p><br>

				<!-- <h3 class="btn3">Rs. 150/-</h3> -->
				<br>
			  <a href="#appointment" id="swineflu" class="appointment-btn btn1 scrollto" data-bs-toggle="modal" data-bs-target="#exampleModal" ><span class="d-none d-md-inline"></span>Book Test</a>
            </div>
          </div>
			   			      <div class="col-12 col-md-6 col-lg-3 mb-3 btn2  ">
            <div class="icon-box2 h-100 ">
              <h4><a href="https://precisionpathlab.com/allergy-test-in-jaipur.php">Allergy Test </a></h4>
              <p> <b>Report Delivery:</b> Same Day</p><br>

				<!-- <h3 class="btn3">Rs. 150/-</h3> -->
				<br>
			  <a href="#appointment" id="swineflu" class="appointment-btn btn1 scrollto" data-bs-toggle="modal" data-bs-target="#exampleModal" ><span class="d-none d-md-inline"></span>Book Test</a>
            </div>
          </div>
			   <div class="col-12 col-md-6 col-lg-3 mb-3 btn2">
            <div class="icon-box2 h-100 ">
              <h4><a href="https://precisionpathlab.com/allergy-test-in-jaipur.php">Frozen Section </a></h4>
              <p> <b>Report Delivery:</b> Within 20 minutes after sample received in lab </p><br>

				<!-- <h3 class="btn3">Rs. 150/-</h3> -->
				<br>
			  <a href="#appointment" id="swineflu" class="appointment-btn btn1 scrollto" data-bs-toggle="modal" data-bs-target="#exampleModal" ><span class="d-none d-md-inline"></span>Book Test</a>
            </div>
          </div>
			   <div class="col-12 col-md-6 col-lg-3 mb-3 btn2">
            <div class="icon-box2 h-100 ">
              <h4><a href="https://precisionpathlab.com/allergy-test-in-jaipur.php">IHC Markers</a></h4>
              <p> <b>Report Delivery:</b> 2- 4 Days </p><br>

				<!-- <h3 class="btn3">Rs. 150/-</h3> -->
				<br>
			  <a href="#appointment" id="swineflu" class="appointment-btn btn1 scrollto" data-bs-toggle="modal" data-bs-target="#exampleModal" ><span class="d-none d-md-inline"></span>Book Test</a>
            </div>
          </div>
			   
		  </div>

      </div>
    </section><!-- End Services Section -->
	  <section>
		  <div class="container">
		  <div class="row">
			  <div class="col-12">
				  Here are some of the most common ranges of tests with their prices, we also offer budget-friendly combined <a href="https://precisionpathlab.com/full-body-check-up-in-jaipur.php">health packages</a>. For detailed pricing on your required tests <a href="https://precisionpathlab.com/#appointment">contact us</a>. Our team is ready to assist you.
			  </div>
		  </div>
		  </div>
	  </section>

  </main><!-- End #main -->
<!--book-test popup-->
	<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" style="margin-top: 8%;">
	  	<form method="post" action="book-a-test.php">
    <div class="modal-content">
      <div class="modal-header ">
        <h2 class="modal-title fs-5 " id="exampleModalLabel" style="color: #2c4964;">Book Test</h2>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body p-4">
       
			<div class="row">
				<div class="col-md-12 mb-2">
					<label  class="form-label">Name</label>
					<input type="text" name="name" class="form-control" required >
				</div>
				<div class="col-md-6 mb-2">
					<label  class="form-label">E-mail (optional)</label>
					<input type="text" name="email" class="form-control">
				</div>
				<div class="col-md-6 mb-2">
					<label class="form-label">Phone Number</label>
					<input type="text"name="phone" class="form-control" required>
				</div>
				
				<div class="col-md-6 mb-2">
					<p>Date: <input type = "text" name="dob" id = "datepicker-1" required></p>
				</div>
				
				<!-- <div class="col-md-12 mb-2">
					<label class="form-label">Test Name</label>
					<select class="form-select" aria-label="Default select example">
					  <option value="" selected disabled>select</option>
						 <option value="1">COMPLETE BLOOD COUNT[CBC]</option>
						 <option value="2">ESR [FULLY AUTOMATED] </option>
						 <option value="3">LFT</option>
						 <option value="1">KFT </option>
						 <option value="1">BLOOD GROUP </option>
						 <option value="1">GLYCOSYLATED HB [HbA1c]</option>
						 <option value="1">VITAMIN B12</option>
						 <option value="1">TSH </option>
						 <option value="1">SMALL BIOPSY </option>
						 <option value="1">URINE ROUTINE EXAMINATION </option>
						 <option value="1">LIPID PROFILE - Serum </option>
						 <option value="1">CREATININE</option>
						 <option value="1">BLOOD SUGAR RANDOM</option>
						 <option value="1">FT3,FT4,TSH </option>
						 <option value="1">SGOT (AST) </option>
						 <option value="1">SGPT (ALT) </option>
					</select>
				</div>-->
				<div class="col-md-12 mb-2">
					<label class="form-label">Message</label>
					 <textarea class="form-control" name="message" id="exampleFormControlTextarea1" rows="3" required></textarea>
				</div>
			</div>
		
      </div>
      <div class="modal-footer">
        <button type="button"  class="btn btn-secondary" data-bs-dismiss="modal" style="border-radius: 25px;">Close</button>
        <button type="submit"  class="btn appointment-btn">Send</button>
      </div>
    </div>
	  	</form>
  </div>
</div>
  <!-- ======= Footer ======= -->
 <footer id="footer">

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-contact">
            <h3>PRECISION HOUSE</h3>
            <p>
			  <i class="bi bi-geo-alt"></i> :
			  72/2, Shipra Path, Mansarovar<br>
 			  Jaipur 302020 (India)<br><br>
              <i class="bi bi-phone"></i> : +91 8696222281, 8696222678<br>
              <i class="bi bi-envelope"></i> : info@precisionpathlab.com<br>
            </p><br>

			  <h5>Our Timing</h5>
			  <p><b>Monday to Saturday </b><br>
 					8:00 AM to 8:30 PM<br>
				 <b>Sunday</b><br>
					8:00 AM to 2:30 PM</p>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
            <h4>Quick Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="https://precisionpathlab.com/">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="about.php">About us</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="full-body-check-up-in-jaipur.php">Health Packages</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="laboratories.php">Our Laboratories</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Home Collection</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="https://precisionpathlab.com/blog/">Our Blog</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="contact.php">Contact Us</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Our Services</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Pathology Testing</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Microscopic Testing</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">X-Ray</a></li>
			 <li><i class="bx bx-chevron-right"></i> <a href="https://precisionpathlab.com/feedback.php">Feedback</a></li>
            </ul>
          </div>

          <div class="col-lg-4 col-md-6 footer-newsletter">
            <h4 class="text-center">Reach Us</h4>
			  <div class="row">
				  <div class="col-6">
					  <b>Mansarovar</b><br>
			  <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14238.140506209242!2d75.7730997!3d26.8547344!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396db5230f2899a5%3A0xde62d7d0e085d8c3!2sPrecision%20Path%20Lab%20%7C%20Path%20Lab%20in%20Jaipur%20%7C%20Mansarovar!5e0!3m2!1sen!2sin!4v1680676109737!5m2!1sen!2sin" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
           </div>
				   <div class="col-6">
					   <b>Vaishali Nagar</b><br>
			  <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3558.0547805694996!2d75.7413212!3d26.901756499999994!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396db51d7e983483%3A0x80687443d6f95370!2sPrecision%20Path%20Lab%20%7C%20Best%20Diagnostic%20Centre%20%7C%20Full%20body%20Checkup%20in%20Vaishali%20Nagar%2C%20Jaipur!5e0!3m2!1sen!2sin!4v1690892304193!5m2!1sen!2sin" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
           </div>
				  </div>
          </div>

        </div>
      </div>
    </div>

    <div class="container d-md-flex py-4">

      <div class="me-md-auto text-center text-md-start">
        <div class="copyright">
          &copy; Copyright 2024 <strong><span>Precision Path Lab</span></strong>. All Rights Reserved.
        </div>
        <!--<div class="credits">
          Designed by <a href="https://thecogent.in/best-digital-marketing-company-in-jaipur">Digital Marketing Company in Jaipur</a>
        </div>-->
      </div>
      <div class="social-links text-center text-md-right pt-3 pt-md-0">
        <a href="https://www.facebook.com/precisonpathlab" class="facebook"><i class="bx bxl-facebook"></i></a>
        <a href="https://www.instagram.com/precisionpathlab/" class="instagram"><i class="bx bxl-instagram"></i></a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <div class="whatsapp-widget">
    <a href="https://wa.me/+917230002896" target="_blank">
      <img src="../img/whatsapp1.png" alt="WhatsApp" width="50px">
	 
		  <b class="text-white">Let's chat</b>
	  
    </a>
	 
  </div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
	
	<script>
function tabSwithch() {
  location.replace("/full-body-check-up-in-jaipur.php");
}
</script>
	<script>
    // Add event listener to show/hide the WhatsApp widget on scroll
    window.addEventListener('scroll', function() {
      var whatsappWidget = document.querySelector('.whatsapp-widget');
      var scrollPosition = window.scrollY || window.pageYOffset;

      if (scrollPosition > 100) {
        whatsappWidget.style.right = '15px';
      } else {
        whatsappWidget.style.right = '-170px';
      }
    });
  </script>

</body>

</html>