<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=0" /> 

  <title>Accurate Allergy Test in Jaipur - Precision Pathlab </title>
  <meta content="Get accurate allergy test in Jaipur at Precision Pathlab. Quick results, expert analysis, and personalized care to help you manage your allergies effectively. " name="description">
  <meta content="" name="keywords">
	<meta property="og:image" content="https://precisionpathlab.com/assets/img/pathlab.png">
	
	<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-D8QG004XC3"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-D8QG004XC3');
</script>

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">


  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

 <link rel="canonical" href="https://precisionpathlab.com/allergy-test-in-jaipur.php">
  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
	<style>
		.colwidth{
			width:32%;
		}
		@media (max-width:576px){
			.colwidth{
				width:100%!important;
			}
	</style>
 
</head>

<body>

  <!-- ======= Top Bar ======= -->
  <div id="topbar" class="d-flex align-items-center fixed-top">
    <div class="container d-flex justify-content-between">
      <div class="contact-info d-flex align-items-center">
        <i class="bi bi-envelope"></i> <a href="mailto:contact@example.com">info@precisionpathlab.com</a>
        <i class="bi bi-phone"></i> +91-7230002896 
      </div>
      <div class="d-none d-lg-flex social-links align-items-center">
        <a href="https://www.facebook.com/precisonpathlab" class="facebook"><i class="bx bxl-facebook"></i></a>
        <a href="https://www.instagram.com/precisionpathlab/" class="instagram"><i class="bi bi-instagram"></i></a>
      </div>
    </div>
  </div>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center">

		<a href="https://precisionpathlab.com/" class="logo me-auto"><img src="assets/img/pathlab.png" alt="Precision Pathlab" class="img-fluid"></a>

		<nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="nav-link scrollto" href="https://precisionpathlab.com/">Home</a></li>
          <li><a class="nav-link scrollto" href="about.php">About Us</a></li>
          <li><a class="nav-link scrollto active" href="book-test.php">Book a Test</a></li>
          <li><a class="nav-link scrollto" href="full-body-check-up-in-jaipur.php">Health Packages</a></li>
          <li><a class="nav-link scrollto" href="laboratories.php">Our Laboratories</a></li>
          <li><a class="nav-link scrollto" href="home-collection.php">Home Collection</a></li>
          <li><a class="nav-link scrollto" href="contact.php">Contact</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

<a href="http://175.111.130.182/precision/design/online_lab/default.aspx" target="_blank" class="appointment-btn scrollto"><span class="d-none d-md-inline">Online</span> Report</a>
    </div>
  </header><!-- End Header -->
	<div style="height:130px;"></div>
	<div class="container">
		
		<div class="row">
			<div class="col-lg-6 mt-4">
			<form style="box-shadow:1px 1px 1px 3px; border-radius:20px; padding:15px;">
  <div class="mb-3">
	  <h3><b class="text-danger">Allergy Test in Jaipur</b></h3>
	  <b>20+ Allergens Included</b>
   <hr>
	  <div class="row">
		  <div class="col-5">
		  <h5><b>MRP -  5400</b></h5> 
		  </div>
		  <div class="col-7">
			 <b>Recommended For</b><br>  <b><img src="img/male.svg">  Male  &nbsp; <img src="img/female.svg">  Female <img src="img/boy.png">  Child</b>
			 
		  </div>
	  </div>
  </div>
	<hr>
  <div class="mb-3">
    <div class="row">
		  <div class="col-5">
		  <b>Age Group</b><br>
			  <b><img src="img/group.svg"> 0-99 Years</b>
		  </div>
		 <div class="col-7">
		  <b>Report Generation Time</b><br>
			  <b><img src="img/watch.svg">  Same Day</b>
		  </div>
		 
	  </div>
  </div><hr>
				<div class="mb-3">
    <div class="row">
		  <div class="col-12">
			  <b>Collaction At</b><br>
<img src="img/home_visit.svg"> Home &nbsp;  <img src="img/labflask.svg"> Lab  

		  </div>
		
		 
	  </div>
  </div><hr>
  <a class="text-white btn btn-primary w-100" href="https://precisionpathlab.com/contact.php" >Book Now</a>
</form>
			</div>
			<div class="col-lg-6 mt-4">
				<h1>Fast & Accurate Allergy Testing in Jaipur at Your Trusted Pathlab</h1>
				<p style="border:solid 1px black; padding:5px;">Are you suffering from unexplained symptoms like sneezing, itching, or digestive issues? Understanding your allergies can provide relief and improve your quality of life. At Precision Pathlab, we offer comprehensive CRD allergy test services in Jaipur to identify allergens that may be affecting your health.</p>
			
				
				<img src="img/medical.png" height="70">
					<img src="img/medical-team.png" style="padding-left:40px;" height="70">
				<img src="img/blood-test.png" style="padding-left:40px;" height="70">
				
			</div>
			<div class="row mt-4">
				<div class="col-12">
					<h3>Our Allergy Testing Services</h3>
				<p>At Precision Path Lab, we offer a variety of allergy test in Jaipur to cater to different needs. Our services include:</p>
					<p><b>Inhalation India Basic</b></p>
				<p>This test is designed to detect common airborne allergens that may cause respiratory issues such as asthma, allergic rhinitis, and other related conditions. It covers a wide range of inhalant allergens found in India, including pollen, dust mites, and molds.</p>
					<p><b>Inhalation India Extended</b></p>
					<p>For a more comprehensive analysis, our Inhalation India Extended test includes a broader spectrum of airborne allergens. This test is ideal for individuals who experience severe or persistent respiratory symptoms and need a thorough assessment of potential triggers.</p>
					<p><b>Food India Basic</b></p>
					<p>Food allergies can lead to a variety of symptoms, from mild discomfort to severe reactions. Our Food India Basic test helps identify common food allergens prevalent in the Indian diet. This test covers a range of food items, helping you understand which foods might be causing your allergic reactions.</p>
					<p><b>Food India Extended</b></p>
					<p>Our Food India Extended test provides an extensive evaluation of food allergens. It includes a wider array of food items beyond the basics, offering a detailed understanding of your dietary sensitivities and helping you make informed dietary choices.</p>
					<p><b>Pediatric Allergy Testing</b></p>
					<p>Children are particularly vulnerable to allergies, and early detection is essential for effective management. Our Pediatric Allergy Testing in Jaipur is tailored specifically for young patients, focusing on common pediatric allergens. This test helps identify allergens that may affect your child's health and well-being, ensuring they receive the appropriate care and treatment.</p>
				</div>
			</div>
		</div><br>
		
		   <section id="services" class="services">
      <div class="container">

        <div class="section-title">
          <h2>Different Type of Allergy Test in Jaipur Offered by Us</h2><br>

        </div>

        <div class="row justify-content-center">
			
          <div class="col-lg-4 col-md-6 mb-4 d-flex align-items-stretch box btn2">
		   <div class="ribbon ribbon-top-left"><span>Rs. 5400/-</span></div>
            <div class="icon-box">
              <div class="icon"><img src="assets/img/icon1.png" width="50" height="50"></div>
              <h4><a href="">Inhalation India Basic Allergy Test</a></h4>
              <p>(Include 18 Allergens )</p>
				<p>Timothy grass, Eucalyptus, Cultivated com, False ragweed , Dandelion, Goldenrod, Sunflower, Dermatophagoides pteronyssins,  dermatophagoides farince, Cockroach,Cat, Dog, Cow, Pigeon feathers, Chicken feathers, Aspergillus fumigats , Trichophyton mentagrophytes CCD marker Indicator.</p>
				<br>
			  <a href="https://precisionpathlab.com/contact.php" class="appointment-btn scrollto btn1"><span class="d-inline">Book</span> Test</a>
            </div>
			  
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-md-0 mb-4 box btn2" >
		  <div class="ribbon ribbon-top-left"><span>Rs. 8700/-</span></div>
            <div class="icon-box">
              <div class="icon"><img src="assets/img/icon2.png" width="50" height="50"></div>
              <h4><a href="">Inhalation India Extended Allergy Test</a></h4>
				<p>(Include  29 Allergens )
              <p>Bermuda grass , Timothy gross, Johnson grass, Cultivated rye , Cultivated com, Eucalyptus, Mesquite (Prosopis juifiora), Mugwort Ox-eye daisy Dandelion, Goose foot, w12 Goldenrod, Cocklebur, Rough pigweed, Sunflower , Dermatophagoides pteronysius,  Dermatophagoides farinae , Cockroach, Penicillium notatum , Cladosporium herbarum ,Aspergillus fumigatus,  Mucor racemosus , Candida albicons , Altemaria antemato , Trichophyton mentagrophytes , cat , dog ,Pigeon feathers, Chicken feathers and CCD marker Indicator.</p>
				<br>
			  <a href="https://precisionpathlab.com/contact.php" class="appointment-btn scrollto btn1"><span class="d-inline">Book</span> Test</a>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-lg-0 mb-4 box btn2">
            <div class="ribbon ribbon-top-left"><span>Rs. 5400/-</span></div>
            <div class="icon-box">
              <div class="icon"><img src="assets/img/icon3.png" width="50" height="50"></div>
              <h4><a href="">Food India Basic Allergy Test</a></h4>
				<p>(Include 20 Allergens )</p>
              <p>Egg White, Cow's milk, Yogurt, Egg yolk , Wheat flour , Rice , Soybean , Peanut , Coconut , Apple , Grape blue , Potato , Spinach , Onion , Cucumber , Chicken , Mustard seed , Ginger , Crab , Shrim/Prawn and CCD market Indicator.</p>
			  <br>
			  <a href="https://precisionpathlab.com/contact.php" class="appointment-btn scrollto btn1"><span class="d-inline">Book</span> Test</a>
            </div>
          </div>
		  
		  <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-lg-0 mb-4 box btn2">
            <div class="ribbon ribbon-top-left"><span>Rs. 8600/-</span></div>
            <div class="icon-box">
              <div class="icon"><img src="assets/img/icon4.png" width="50" height="50"></div>
              <h4><a href="">Food India Extended Allergy Test</a></h4>
				<p>(Include 38 Allergens )</p>
              <p>Egg White , Egg yolk, Cow's milk, Yogurt, Wheat flour, Gluten, Oat flour, Maize flour Rice, Soybean ,Peanut , Almond , Citrus mix 2: Grapefruit, Lemon, Orange, Mandarin , Orange , Coconut ,Apple Grope, blue ,Pea, Tomato , Potato , Spinach ,Onion, Garlic, Chickpea, Cucumber, Eggplant, Pigeon pea, Mungbean, Deel, Chicken , Lamb meat , Mustard seed , Ginger , Spice mix 3: Chili pepper, Red pepper , Codfish , Crab, Shrimp/Prawn , Rohu and CCD marker Indicator.</p><br>

			  <a href="https://precisionpathlab.com/contact.php" class="appointment-btn scrollto btn1"><span class="d-inline">Book</span> Test</a>
            </div>
          </div>
			
			 <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mb-4 mt-lg-0 box btn2">
            <div class="ribbon ribbon-top-left"><span>Rs. 6000/-</span></div>
            <div class="icon-box">
              <div class="icon"><img src="assets/img/icon1.png" width="50" height="50"></div>
              <h4><a href="">Pediatrics Allergy Test</a></h4>
				<p>(Include 27 Allergens )</p>
              <p>Grass mix 2 : Timothy grass, Cultivatedrye  , Birch , Mugwort , Dermatopha goides pteronyssinus, Dermatopha goides farinae, Cat , Dog , Horse , Cladosporium herbarum ,Aspergillus fumigatus, Alternaria alternato , Egg white , Eggyolk , Cow's milk , Codfish nBood 4 Al Pholactalbumin (milk) , nosd 5 Beta-lactoglobulin (Milk), nBosd 8 Casein (MK), nBood 6 Bsa (Milk), Wheat flour , Rice , Soybean, Peanut Hazelnut , Carrot , Potato , Apple and CCD marker indicator.</p><br>

			  <a href="https://precisionpathlab.com/contact.php" class="appointment-btn scrollto btn1"><span class="d-inline">Book</span> Test</a>
            </div>
          </div>

        </div>
      </div>
    </section>
		<!-- End Services Section -->
		
		<div class="row">
			<div  class="col-12">
				<h3 class="text-center">Common Allergy Symptoms You Shouldn't Ignore</h3>
				<div class="row mb-4 g-3 justify-content-evenly">
					<div class="col-lg-4 col-md-6 col-12 p-3 colwidth" style="border:8px groove #e1e1e1;">
						<ul>
							<li class="mb-1"> Fatigue</li>
							<li class="mb-1"> Headache</li>
							<li class="mb-1">Abdominal pain</li>
							<li class="mb-1">Diarrhea</li>
						</ul>
					</div>
					<div class="col-lg-4 col-md-6 col-12 p-3 colwidth" style="border:8px groove #e1e1e1;">
						<ul>
							<li class="mb-1">Nausea</li>
							<li class="mb-1"> Vomiting</li>
							<li class="mb-1">Sneezing</li>
							<li class="mb-1">Runny or stuffy nose</li>
						</ul>
					</div>
					<div class="col-lg-4 col-md-6 col-12 p-3 colwidth" style="border:8px groove #e1e1e1;">
						<ul>
							<li class="mb-1"> Coughing</li>
							<li class="mb-1"> Wheezing</li>
							<li class="mb-1"> Shortness of breath</li>
							<li class="mb-1"> Itchy or watery eyes</li>
						</ul>
					</div>
				</div>
				<div class="col-12 mb-4">
					<h3 class="mt-2">How It Works</h3>
					<ol>
						<li class="mb-2"><b>Book Your Test:</b> Schedule your CRD Allergy Test online or by contacting our customer service.</li>
						<li class="mb-2"><b>Sample Collection:</b> A qualified technician will collect your blood sample at your convenience.</li>
						<li class="mb-2"><b>Testing:</b> Your sample will be analyzed in our state-of-the-art laboratory.</li>
						<li class="mb-2"><b>Receive Results:</b> Get your detailed report within a few days.</li>
						<li class="mb-2"><b>Consultation:</b> Discuss your results with our allergy specialist to plan your next steps.</li>
					</ol>
				</div>
				
								<div class="col-12">
					<h3 class="mt-2">Why Choose Precision Path Lab?</h3>
					<ul>
						<li class="mb-2"><b>Expertise and Experience:</b> Our team of skilled professionals has extensive experience in allergy testing and diagnostics.</li>
						<li class="mb-2"><b>Advanced Technology:</b> We use cutting-edge technology and methodologies to ensure accurate and reliable results.</li>
						<li class="mb-2"><b>Personalized Care:</b> We understand that each individual is unique, and we provide personalized care and advice based on your specific needs.</li>
						<li class="mb-2"><b>Comprehensive Reports:</b> Our detailed reports help you understand your allergies better and provide actionable insights for managing your symptoms.</li>
						
					</ul>
				</div>
				
				
			</div>
		</div>
					
		</div>
		
	

  <!-- ======= Footer ======= -->
 <footer id="footer">

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-contact">
            <h3>PRECISION HOUSE</h3>
            <p>
			  <i class="bi bi-geo-alt"></i> :
			  72/2, Shipra Path, Mansarovar<br>
 			  Jaipur 302020 (India)<br><br>
              <i class="bi bi-phone"></i> : +91 8696222281, 8696222678<br>
              <i class="bi bi-envelope"></i> : info@precisionpathlab.com<br>
            </p><br>

			  <h5>Our Timing</h5>
			  <p><b>Monday to Saturday </b><br>
 					8:00 AM to 8:30 PM<br>
				 <b>Sunday</b><br>
					8:00 AM to 2:30 PM</p>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
            <h4>Quick Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="https://precisionpathlab.com/">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="about.php">About us</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="full-body-check-up-in-jaipur.php">Health Packages</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="laboratories.php">Our Laboratories</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Home Collection</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="https://precisionpathlab.com/blog/">Our Blog</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="contact.php">Contact Us</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Our Services</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Pathology Testing</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Microscopic Testing</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">X-Ray</a></li>
			 <li><i class="bx bx-chevron-right"></i> <a href="https://precisionpathlab.com/feedback.php">Feedback</a></li>
            </ul>
          </div>

          <div class="col-lg-4 col-md-6 footer-newsletter">
            <h4 class="text-center">Reach Us</h4>
			  <div class="row">
				  <div class="col-6">
					  <b>Mansarovar</b><br>
			  <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14238.140506209242!2d75.7730997!3d26.8547344!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396db5230f2899a5%3A0xde62d7d0e085d8c3!2sPrecision%20Path%20Lab%20%7C%20Path%20Lab%20in%20Jaipur%20%7C%20Mansarovar!5e0!3m2!1sen!2sin!4v1680676109737!5m2!1sen!2sin" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
           </div>
				   <div class="col-6">
					   <b>Vaishali Nagar</b><br>
			  <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3558.0547805694996!2d75.7413212!3d26.901756499999994!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396db51d7e983483%3A0x80687443d6f95370!2sPrecision%20Path%20Lab%20%7C%20Best%20Diagnostic%20Centre%20%7C%20Full%20body%20Checkup%20in%20Vaishali%20Nagar%2C%20Jaipur!5e0!3m2!1sen!2sin!4v1690892304193!5m2!1sen!2sin" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
           </div>
				  </div>
          </div>

        </div>
      </div>
    </div>

    <div class="container d-md-flex py-4">

      <div class="me-md-auto text-center text-md-start">
        <div class="copyright">
          &copy; Copyright 2025 <strong><span>Precision Path Lab</span></strong>. All Rights Reserved.
        </div>
        <!--<div class="credits">
          Designed by <a href="https://thecogent.in/best-digital-marketing-company-in-jaipur">Digital Marketing Company in Jaipur</a>
        </div>-->
      </div>
      <div class="social-links text-center text-md-right pt-3 pt-md-0">
        <a href="https://www.facebook.com/precisonpathlab" class="facebook"><i class="bx bxl-facebook"></i></a>
        <a href="https://www.instagram.com/precisionpathlab/" class="instagram"><i class="bx bxl-instagram"></i></a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
	<a href="https://api.whatsapp.com/send?phone=+917230002896%27&amp;text=Hey" target="_blank" class="whatsaap-icon d-flex align-items-center justify-content-center"><i class="bi bi-whatsapp"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>