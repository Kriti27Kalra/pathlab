<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=0" /> 

  <title> Precision Path Lab |Feedback</title>
  <meta content="" name="description">
  <meta content="" name="keywords">
  <meta name="robots" content="noindex">
	<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-D8QG004XC3"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-D8QG004XC3');
</script>

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
	<style>
		h6{
			font-weight:bolder;
		  }
		label
		{
			font-weight:bolder;
		}
	</style>
 
</head>

<body>

  <!-- ======= Top Bar ======= -->
  <div id="topbar" class="d-flex align-items-center fixed-top">
    <div class="container d-flex justify-content-between">
      <div class="contact-info d-flex align-items-center">
        <i class="bi bi-envelope"></i> <a href="mailto:contact@example.com">info@precisionpathlab.com</a>
        <i class="bi bi-phone"></i> +91-7230002896 
      </div>
      <div class="d-none d-lg-flex social-links align-items-center">
        <a href="https://www.facebook.com/profile.php?id=100089280827418 " class="facebook"><i class="bx bxl-facebook"></i></a>
        <a href="https://www.instagram.com/precisionpathlab/" class="instagram"><i class="bi bi-instagram"></i></a>
      </div>
    </div>
  </div>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center">

		<a href="https://precisionpathlab.com/" class="logo me-auto"><img src="assets/img/pathlab.png" alt="Precision Pathlab" class="img-fluid"></a>

		<nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="nav-link scrollto" href="https://precisionpathlab.com/">Home</a></li>
          <li><a class="nav-link scrollto" href="about.php">About Us</a></li>
          <li><a class="nav-link scrollto" href="book-test.php">Book a Test</a></li>
          <li><a class="nav-link scrollto" href="full-body-check-up-in-jaipur.php">Health Packages</a></li>
          <li><a class="nav-link scrollto" href="laboratories.php">Our Laboratories</a></li>
          <li><a class="nav-link scrollto" href="home-collection.php">Home Collection</a></li>
          <li><a class="nav-link scrollto" href="contact.php">Contact</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

<a href="http://175.111.130.12/precision/design/online_lab/default.aspx" target="_blank" class="appointment-btn scrollto"><span class="d-none d-md-inline">Online</span> Report</a>
    </div>
  </header><!-- End Header -->
	
	<div class="container p-4" style="margin-top:140px; background-image: linear-gradient(to top, #fff1eb 0%, #ace0f9 100%);">
		<div class="row">
			<div class="col-12">
				<h3 class="text-primary mb-4" style="font-weight:bolder;">Please Complete the Feedback Form....</h3>
				<form method="post">
					<div class="row">
  <div class="col-md-4 mb-4">
	  <label for="exampleInputName" class="form-label" ><b>Name</b></label>
    <input type="text" class="form-control" name="name" placeholder="Enter your name" id="exampleInputtext" aria-describedby="textHelp">
    
  </div>
  <div class="col-md-4 mb-4">
	  <label for="exampleInputPassword1" class="form-label"><b>Date of Visit</b></label>
    <input type="date" max="2025-08-20" name="dateofvisit" class="form-control" id="exampleInputDate">
  </div>
 <div class="col-md-4 mb-4">
	 <label for="exampleInputPhone" class="form-label"><b>Phone</b></label>
    <input type="tel" minlength=10 maxlength=10 placeholder="Enter your phone" name="phone" class="form-control" id="exampleInputPhone">
  </div>
						<hr>
						
  <div class="col-md-4 col-6 mb-3 form-check">
	  <h6>Environment of Lab</h6>
	 <div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions1" id="inlineRadio1" value="Comfortable" required>
  <label class="form-check-label text-success" for="inlineRadio1">Comfortable</label>
</div><br>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions1" id="inlineRadio2" value="NeedsImprovement">
  <label class="form-check-label text-danger" for="inlineRadio2">Needs Improvement</label>
</div>
</div>
	  <div class="col-md-4 col-6 mb-3 form-check">
	  <h6>Services Offered</h6>
	 <div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions2" id="inlineRadio3" value="Good" required>
  <label class="form-check-label text-success" for="inlineRadio1">Good</label>
</div><br>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions2" id="inlineRadio4" value="Average">
  <label class="form-check-label text-warning" for="inlineRadio2">Average</label>
</div><br>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions2" id="inlineRadio5" value="NeedsImprovement">
  <label class="form-check-label text-danger" for="inlineRadio3">Needs Improvement</label>
</div>
</div>	<hr class="d-block d-sm-block d-md-none d-lg-none d-xl-none">
	 <div class="col-md-4 col-6 mb-3 form-check">
	  <h6>Delivery of Report</h6>
	 <div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions3" id="inlineRadio6" value="OnTime" required>
  <label class="form-check-label text-success" for="inlineRadio1">On Time</label>
</div><br>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions3" id="inlineRadio7" value="Delayed">
  <label class="form-check-label text-warning" for="inlineRadio2">Delayed</label>
</div><br>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions3" id="inlineRadio8" value="VeryDelayed">
  <label class="form-check-label text-danger" for="inlineRadio3">Very Delayed</label>
</div>
</div>	<hr class="d-none d-sm-none d-md-block d-lg-block d-xl-block">
		 <div class="col-md-4 col-6 mb-3 form-check">
	  <h6>Waiting time for patient in lab</h6>
	 <div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions4" id="inlineRadio9" value="NoWaitingTime" required>
  <label class="form-check-label text-success" for="inlineRadio1">No Waiting Time</label>
</div><br>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions4" id="inlineRadio10" value="10min">
  <label class="form-check-label text-warning" for="inlineRadio2">10 min</label>
</div><br>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions4" id="inlineRadio11" value="20min">
  <label class="form-check-label" style="color:violet;" for="inlineRadio3">20 min</label>
</div><br>
 <div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions4" id="inlineRadio12" value="30min">
  <label class="form-check-label text-danger"  for="inlineRadio4">30 min</label>
</div>
</div><hr class="d-block d-sm-block d-md-none d-lg-none d-xl-none">
 <div class="col-md-4 col-6 mb-3 form-check">
	  <h6>Cleanliness & Hygiene</h6>
	 <div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions5" id="inlineRadio13" value="Good" required>
  <label class="form-check-label text-success" for="inlineRadio1">Good</label>
</div><br>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions5" id="inlineRadio14" value="Satisfactory">
  <label class="form-check-label text-warning" for="inlineRadio2">Satisfactory</label>
</div><br>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions5" id="inlineRadio15" value="NeedsImprovement">
  <label class="form-check-label text-danger" for="inlineRadio3">Needs Improvement</label>
</div>
</div>	
	<div class="col-md-4 col-6 mb-3 form-check">
	  <h6>Time taken for collection of Sample</h6>
	 <div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions6" id="inlineRadio16" value="Prompt" required>
  <label class="form-check-label text-success" for="inlineRadio1">Prompt</label>
</div><br>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions6" id="inlineRadio17" value="Satisfactory">
  <label class="form-check-label text-warning" for="inlineRadio2">Satisfactory</label>
</div><br>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions6" id="inlineRadio18" value="Prolonged">
  <label class="form-check-label text-danger" for="inlineRadio3">Prolonged</label>
</div>
</div>	<hr>
						
		<div class="col-md-4 col-6 mb-3 form-check">
	  <h6>Method of collection</h6>
	 <div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions7" id="inlineRadio19" value="Comfortable" required>
  <label class="form-check-label text-success" for="inlineRadio1">Comfortable</label>
</div><br>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions7" id="inlineRadio20" value="Uncomfortable">
  <label class="form-check-label text-warning" for="inlineRadio2">Uncomfortable</label>
</div><br>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions7" id="inlineRadio21" value="Painful">
  <label class="form-check-label text-danger" for="inlineRadio3">Painful</label>
</div>
</div>	
	<div class="col-md-4 col-6 mb-3 form-check">
	  <h6>How do you overall rate our laboratory</h6>
	 <div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions8" id="inlineRadio22" value="Excellent" required>
  <label class="form-check-label text-success" for="inlineRadio1">Excellent</label>
</div><br>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions8" id="inlineRadio23" value="Good">
  <label class="form-check-label text-warning" for="inlineRadio2">Good</label>
</div><br>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions8" id="inlineRadio24" value="NeedsImprovement">
  <label class="form-check-label text-danger" for="inlineRadio3">Needs Improvement</label>
</div>
</div>	<hr>
<div class="form-floating">
	<h6>Your Suggestion if Any:</h6>
  <textarea class="form-control" placeholder="Leave a comment here" name="textarea1" id="floatingTextarea2" style="height: 100px"></textarea>
  
</div>
						
						
  </div>
  <button type="submit" class="btn btn-primary mt-4" name="btnsubmit">Submit</button>
                  
</form>
				</div>
			</div>
		</div>
	

  <!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-contact">
            <h3>PRECISION HOUSE</h3>
            <p>
			  <i class="bi bi-geo-alt"></i> :
			  72/2, Shipra Path, Mansarovar<br>
 			  Jaipur 302020 (India)<br><br>
              <i class="bi bi-phone"></i> : +91 8696222281, 8696222678<br>
              <i class="bi bi-envelope"></i> : info@precisionpathlab.com<br>
            </p><br>

			  <h5>Our Timing</h5>
			  <p><b>Monday to Saturday </b><br>
 					8:00 AM to 8:30 PM<br>
				 <b>Sunday</b><br>
					8:00 AM to 2:30 PM</p>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
            <h4>Quick Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="https://precisionpathlab.com/">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="about.php">About us</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="full-body-check-up-in-jaipur.php">Health Packages</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="laboratories.php">Our Laboratories</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Home Collection</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="https://precisionpathlab.com/blog/">Our Blog</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="contact.php">Contact Us</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Our Services</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Pathology Testing</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Microscopic Testing</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">X-Ray</a></li>
			 <li><i class="bx bx-chevron-right"></i> <a href="https://precisionpathlab.com/feedback.php">Feedback</a></li>
            </ul>
          </div>

          <div class="col-lg-4 col-md-6 footer-newsletter">
            <h4 class="text-center">Reach Us</h4>
			  <div class="row">
				  <div class="col-6">
					  <b>Mansarovar</b><br>
			  <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14238.140506209242!2d75.7730997!3d26.8547344!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396db5230f2899a5%3A0xde62d7d0e085d8c3!2sPrecision%20Path%20Lab%20%7C%20Path%20Lab%20in%20Jaipur%20%7C%20Mansarovar!5e0!3m2!1sen!2sin!4v1680676109737!5m2!1sen!2sin" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
           </div>
				   <div class="col-6">
					   <b>Vaishali Nagar</b><br>
			  <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3558.0547805694996!2d75.7413212!3d26.901756499999994!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396db51d7e983483%3A0x80687443d6f95370!2sPrecision%20Path%20Lab%20%7C%20Best%20Diagnostic%20Centre%20%7C%20Full%20body%20Checkup%20in%20Vaishali%20Nagar%2C%20Jaipur!5e0!3m2!1sen!2sin!4v1690892304193!5m2!1sen!2sin" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
           </div>
				  </div>
          </div>

        </div>
      </div>
    </div>

    <div class="container d-md-flex py-4">

      <!--<div class="me-md-auto text-center text-md-start">
        <div class="copyright">
          &copy; Copyright 2023 <strong><span>Precision Path Lab</span></strong>. All Rights Reserved.
        </div>
        <div class="credits">
          Designed by <a href="https://thecogent.in/best-digital-marketing-company-in-jaipur">Digital Marketing Company in Jaipur</a>
        </div>
      </div>-->
      <div class="social-links text-center text-md-right pt-3 pt-md-0">
        <a href="https://www.facebook.com/profile.php?id=100089280827418" class="facebook"><i class="bx bxl-facebook"></i></a>
        <a href="https://www.instagram.com/precisionpathlab/" class="instagram"><i class="bx bxl-instagram"></i></a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
	<a href="https://api.whatsapp.com/send?phone=+917230002896%27&amp;text=Hey" target="_blank" class="whatsaap-icon d-flex align-items-center justify-content-center"><i class="bi bi-whatsapp"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>